# AI 캐리커처 서버의 웹 부분 (Colab 노트북 3번 셀에 그대로 들어간다. make_server_notebook.py가 읽어서 넣음)
# 앞 셀에서 만들어진 draw(), torch, Image, io, time 을 쓴다.
from fastapi import FastAPI, Request, Response
from fastapi.responses import HTMLResponse
from starlette.concurrency import run_in_threadpool
app = FastAPI()
COUNT = {"n": 0, "fail": 0}
PHONE = {"id": 0, "data": None, "t": 0}          # 폰에서 찍어 보낸 사진 (부스가 가져가면 바로 지운다)

@app.get("/health")
def health(): return {"ok": True, "version": 3, "gpu": torch.cuda.get_device_name(0), "count": COUNT["n"]}

@app.post("/caricature")
async def caricature(req: Request, strength: float = 1.5, beauty: int = 0, glasses: int = 0):
    try:
        img = Image.open(io.BytesIO(await req.body()))
        out = await run_in_threadpool(draw, img, strength, beauty, glasses); COUNT["n"] += 1      # 그리는 동안에도 서버가 다른 요청(상태 확인·폰 사진)에 답하도록 따로 돌린다
    except Exception as e:                        # 한 장이 실패해도 서버는 계속 돈다 (부스가 다시 시도)
        COUNT["fail"] += 1; torch.cuda.empty_cache()
        return Response(str(e)[:200], status_code=500)
    buf = io.BytesIO(); out.save(buf, "JPEG", quality=93)
    return Response(buf.getvalue(), media_type="image/jpeg")

PHONE_PAGE = """<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>캐리커처 부스 · 폰으로 찍기</title>
<style>
body{margin:0;font-family:system-ui,sans-serif;background:#0b1a6e;color:#fff;text-align:center;padding:28px 16px}
h1{font-size:24px;margin:6px 0 4px}p{opacity:.85;margin:6px 0 20px;line-height:1.5}
label{display:block;max-width:420px;margin:0 auto 14px;border-radius:18px;font-weight:800}
.main{background:#ffd84d;color:#0b1a6e;font-size:26px;padding:24px}
.alt{border:2px solid rgba(255,255,255,.5);font-size:17px;padding:13px}
input{display:none}#pv{max-width:min(420px,100%);border-radius:14px;margin-top:10px;display:none}
#msg{font-size:19px;font-weight:700;min-height:30px;margin:12px 0}
</style></head><body>
<h1>캐리커처 부스</h1><p>얼굴이 화면에 크게 나오게,<br>정면에서 밝은 곳을 보고 찍어주세요</p>
<label class="main">📷 사진 찍기<input type="file" id="cam" accept="image/*" capture="environment"></label>
<label class="alt">🤳 셀카로 찍기<input type="file" id="selfie" accept="image/*" capture="user"></label>
<label class="alt">앨범에서 고르기<input type="file" id="pick" accept="image/*"></label>
<div id="msg"></div><img id="pv" alt="">
<script>
const msg=document.getElementById('msg'),pv=document.getElementById('pv');
async function send(f){
  if(!f)return; msg.textContent='보내는 중…';
  try{
    const img=new Image(); img.src=URL.createObjectURL(f); await img.decode();
    const k=Math.min(1,1600/Math.max(img.naturalWidth,img.naturalHeight));
    const c=document.createElement('canvas'); c.width=Math.round(img.naturalWidth*k); c.height=Math.round(img.naturalHeight*k);
    c.getContext('2d').drawImage(img,0,0,c.width,c.height);
    const blob=await new Promise(r=>c.toBlob(r,'image/jpeg',0.9));
    const res=await fetch('/phone/upload',{method:'POST',headers:{'Content-Type':'image/jpeg'},body:blob});
    if(!res.ok)throw new Error(res.status);
    pv.src=c.toDataURL('image/jpeg',0.5); pv.style.display='inline';
    msg.textContent='✅ 보냈어요! 부스 화면을 확인하세요';
  }catch(e){msg.textContent='❌ 전송 실패. 다시 시도해 주세요';}
}
for(const id of ['cam','selfie','pick'])document.getElementById(id).onchange=e=>{send(e.target.files[0]);e.target.value='';};
</script></body></html>"""

@app.get("/phone", response_class=HTMLResponse)
def phone_page(): return PHONE_PAGE

@app.post("/phone/upload")
async def phone_upload(req: Request):
    data = await req.body()
    if not data or len(data) > 8_000_000: return Response("사진이 없거나 너무 커요", status_code=400)
    PHONE.update(id=PHONE["id"] + 1, data=data, t=time.time())
    return {"ok": True, "id": PHONE["id"]}

@app.get("/phone/state")
def phone_state(): return {"id": PHONE["id"]}

@app.get("/phone/latest")
def phone_latest(after: int = 0):
    if PHONE["data"] is not None and time.time() - PHONE["t"] > 120: PHONE["data"] = None   # 2분 넘게 안 가져가면 버린다
    if PHONE["data"] is None or PHONE["id"] <= after: return Response(status_code=204)
    data, PHONE["data"] = PHONE["data"], None
    return Response(data, media_type="image/jpeg", headers={"X-Photo-Id": str(PHONE["id"])})
