@echo off
chcp 65001 > nul
cd /d %~dp0
if not exist .venv (
  echo [처음 실행] 가상환경을 만들고 라이브러리를 설치합니다...
  python -m venv .venv
  .venv\Scripts\python -m pip install -r requirements.txt
)
if not exist models\animegan_face_paint_512_v2.onnx (
  .venv\Scripts\python tools\download_models.py
)
start "" cmd /c "timeout /t 6 > nul & start http://localhost:8000"
.venv\Scripts\python server\app.py
pause
