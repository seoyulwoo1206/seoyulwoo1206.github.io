"""
models 폴더가 비어 있을 때 모델을 내려받고 변환한다. (zip에 이미 들어 있으면 실행할 필요 없음)

    python tools/download_models.py
"""
import subprocess
import sys
import tempfile
import urllib.request
from pathlib import Path

import cv2
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
MODELS = ROOT / "models"
MODELS.mkdir(exist_ok=True)

FILES = {
    "face_detection_yunet_2023mar.onnx":
        "https://media.githubusercontent.com/media/opencv/opencv_zoo/main/models/face_detection_yunet/face_detection_yunet_2023mar.onnx",
    "u2netp.onnx": "https://github.com/danielgatis/rembg/releases/download/v0.0.0/u2netp.onnx",
}
ANIMEGAN = "https://github.com/bryandlee/animegan2-pytorch/raw/main/weights/{}.pt"
STYLES = ["face_paint_512_v2", "face_paint_512_v1", "celeba_distill", "paprika"]


def get(url, dst):
    if dst.exists():
        print("있음:", dst.name)
        return
    print("받는 중:", dst.name)
    urllib.request.urlretrieve(url, dst)


for name, url in FILES.items():
    get(url, MODELS / name)

# face_mesh_468.onnx(MediaPipe Face Mesh, tflite→onnx 변환)와 mean_face_468.npy(표준 얼굴)는 zip에 포함돼 있다.
for name in ("face_mesh_468.onnx", "mean_face_468.npy"):
    if not (MODELS / name).exists():
        raise SystemExit(f"{name} 이 없어요. 원본 zip의 models 폴더에서 복사해 주세요.")

if not all((MODELS / f"animegan_{s}.onnx").exists() for s in STYLES):
    with tempfile.TemporaryDirectory() as tmp:
        for s in STYLES:
            get(ANIMEGAN.format(s), Path(tmp) / f"{s}.pt")
        subprocess.run([sys.executable, str(ROOT / "tools" / "convert_animegan_onnx.py"), tmp, str(MODELS)], check=True)
print("모델 준비 완료!")
