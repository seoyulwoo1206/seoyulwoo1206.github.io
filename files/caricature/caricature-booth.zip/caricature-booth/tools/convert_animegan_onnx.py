"""
AnimeGANv2(PyTorch 가중치, MIT 라이선스 - bryandlee/animegan2-pytorch)를
ONNX 모델로 변환한다. PyTorch 설치 없이 동작한다.

사용법:
    python tools/convert_animegan_onnx.py <weights 폴더> <출력 폴더>

변환된 모델은 onnxruntime 하나로 CPU에서 빠르게 돌아간다 (책 8장 '모델 서빙' 참고:
학습 프레임워크와 서빙 런타임을 분리하는 것).
"""
import io
import pickle
import sys
import zipfile
from collections import OrderedDict
from pathlib import Path

import numpy as np
import onnx
from onnx import TensorProto, helper, numpy_helper

SIZE = 512  # 입력 해상도 (고정)


# ---------------------------------------------------------------------------
# 1) torch 없이 .pt 파일(zip + pickle)에서 텐서 꺼내기
# ---------------------------------------------------------------------------
_DTYPES = {
    "FloatStorage": np.float32,
    "HalfStorage": np.float16,
    "DoubleStorage": np.float64,
    "LongStorage": np.int64,
    "IntStorage": np.int32,
}


class _StorageType:
    def __init__(self, name):
        self.dtype = _DTYPES[name]


def _rebuild_tensor_v2(storage, offset, size, stride, *args):
    data, dtype = storage
    itemsize = np.dtype(dtype).itemsize
    if len(size) == 0:
        return np.array(data[offset], dtype=dtype)
    arr = np.lib.stride_tricks.as_strided(
        data[offset:], shape=tuple(size), strides=tuple(s * itemsize for s in stride)
    )
    return np.ascontiguousarray(arr)


def _rebuild_parameter(tensor, *args):
    return tensor


def load_state_dict(path):
    zf = zipfile.ZipFile(path)
    pkl_name = next(n for n in zf.namelist() if n.endswith("data.pkl"))
    root = pkl_name[: -len("data.pkl")]

    class U(pickle.Unpickler):
        def find_class(self, module, name):
            if module == "torch._utils" and name == "_rebuild_tensor_v2":
                return _rebuild_tensor_v2
            if module == "torch._utils" and name == "_rebuild_parameter":
                return _rebuild_parameter
            if module == "torch" and name.endswith("Storage"):
                return lambda: name  # placeholder
            if module == "collections" and name == "OrderedDict":
                return OrderedDict
            raise pickle.UnpicklingError(f"허용되지 않은 객체: {module}.{name}")

        def persistent_load(self, pid):
            _, storage_type, key, _location, _numel = pid
            stype = storage_type if isinstance(storage_type, str) else storage_type()
            dtype = _DTYPES[stype]
            raw = zf.read(f"{root}data/{key}")
            return (np.frombuffer(raw, dtype=dtype), dtype)

    return U(io.BytesIO(zf.read(pkl_name))).load()


# ---------------------------------------------------------------------------
# 2) Generator 구조를 ONNX 그래프로 다시 쌓기 (model.py와 동일한 구조)
# ---------------------------------------------------------------------------
class G:
    def __init__(self, sd):
        self.sd = sd
        self.nodes, self.inits = [], []
        self.n = 0

    def name(self, p):
        self.n += 1
        return f"{p}_{self.n}"

    def const(self, arr, p="c"):
        nm = self.name(p)
        self.inits.append(numpy_helper.from_array(np.asarray(arr), nm))
        return nm

    def w(self, key):
        nm = key
        if nm not in {i.name for i in self.inits}:
            self.inits.append(numpy_helper.from_array(self.sd[key].astype(np.float32), nm))
        return nm

    def op(self, op_type, inputs, **attrs):
        out = self.name(op_type.lower())
        self.nodes.append(helper.make_node(op_type, inputs, [out], **attrs))
        return out

    # 패딩: (left, right, top, bottom)
    def pad(self, x, lrtb, mode="reflect"):
        l, r, t, b = lrtb
        if l == r == t == b == 0:
            return x
        pads = self.const(np.array([0, 0, t, l, 0, 0, b, r], dtype=np.int64), "pads")
        return self.op("Pad", [x, pads], mode=mode)

    def conv(self, x, prefix, k, stride=1, groups=1, bias=False):
        ins = [x, self.w(prefix + ".weight")]
        if bias:
            ins.append(self.w(prefix + ".bias"))
        return self.op("Conv", ins, kernel_shape=[k, k], strides=[stride, stride], group=groups)

    def groupnorm1(self, x, prefix, eps=1e-5):
        mean = self.op("ReduceMean", [x], axes=[1, 2, 3], keepdims=1)
        d = self.op("Sub", [x, mean])
        var = self.op("ReduceMean", [self.op("Mul", [d, d])], axes=[1, 2, 3], keepdims=1)
        std = self.op("Sqrt", [self.op("Add", [var, self.const(np.array(eps, np.float32))])])
        y = self.op("Div", [d, std])
        C = self.sd[prefix + ".weight"].shape[0]
        g = self.const(self.sd[prefix + ".weight"].reshape(1, C, 1, 1).astype(np.float32), "gamma")
        b = self.const(self.sd[prefix + ".bias"].reshape(1, C, 1, 1).astype(np.float32), "beta")
        return self.op("Add", [self.op("Mul", [y, g]), b])

    def cnl(self, x, prefix, k=3, stride=1, padding=1, groups=1, bias=False):
        """ConvNormLReLU: pad -> conv -> groupnorm -> leaky relu"""
        lrtb = padding if isinstance(padding, tuple) else (padding,) * 4
        x = self.pad(x, lrtb)
        x = self.conv(x, prefix + ".1", k, stride, groups, bias)
        x = self.groupnorm1(x, prefix + ".2")
        return self.op("LeakyRelu", [x], alpha=0.2)

    def irb(self, x, prefix, in_ch, out_ch):
        """InvertedResBlock (expansion 2)"""
        bott = in_ch * 2
        y = self.cnl(x, prefix + ".layers.0", k=1, padding=0)
        y = self.cnl(y, prefix + ".layers.1", k=3, groups=bott, bias=True)
        y = self.conv(y, prefix + ".layers.2", 1)
        y = self.groupnorm1(y, prefix + ".layers.3")
        return self.op("Add", [x, y]) if in_ch == out_ch else y

    def resize(self, x, hw):
        # 채널 수는 입력과 같게: Shape에서 가져와 합치기
        shp = self.op("Shape", [x])
        nc = self.op("Slice", [shp, self.const(np.array([0], np.int64)), self.const(np.array([2], np.int64))])
        hw_c = self.const(np.array([hw, hw], dtype=np.int64), "hw")
        sizes = self.op("Concat", [nc, hw_c], axis=0)
        return self.op(
            "Resize", [x, "", "", sizes], mode="linear", coordinate_transformation_mode="align_corners"
        )


def build(sd, out_path):
    g = G(sd)
    x = "input"
    # block_a
    x = g.cnl(x, "block_a.0", k=7, padding=3)
    x = g.cnl(x, "block_a.1", stride=2, padding=(0, 1, 0, 1))
    x = g.cnl(x, "block_a.2")
    # block_b
    x = g.cnl(x, "block_b.0", stride=2, padding=(0, 1, 0, 1))
    x = g.cnl(x, "block_b.1")
    # block_c
    x = g.cnl(x, "block_c.0")
    x = g.irb(x, "block_c.1", 128, 256)
    for i in (2, 3, 4):
        x = g.irb(x, f"block_c.{i}", 256, 256)
    x = g.cnl(x, "block_c.5")
    x = g.resize(x, SIZE // 2)
    # block_d
    x = g.cnl(x, "block_d.0")
    x = g.cnl(x, "block_d.1")
    x = g.resize(x, SIZE)
    # block_e
    x = g.cnl(x, "block_e.0")
    x = g.cnl(x, "block_e.1")
    x = g.cnl(x, "block_e.2", k=7, padding=3)
    # out
    x = g.conv(x, "out_layer.0", 1)
    x = g.op("Tanh", [x])
    g.nodes[-1].output[0] = "output"

    graph = helper.make_graph(
        g.nodes,
        "animegan2_generator",
        [helper.make_tensor_value_info("input", TensorProto.FLOAT, [1, 3, SIZE, SIZE])],
        [helper.make_tensor_value_info("output", TensorProto.FLOAT, [1, 3, SIZE, SIZE])],
        g.inits,
    )
    model = helper.make_model(graph, opset_imports=[helper.make_opsetid("", 13)])
    model.ir_version = 8
    onnx.checker.check_model(model)
    onnx.save(model, out_path)


if __name__ == "__main__":
    src, dst = Path(sys.argv[1]), Path(sys.argv[2])
    dst.mkdir(parents=True, exist_ok=True)
    for pt in sorted(src.glob("*.pt")):
        sd = load_state_dict(pt)
        out = dst / f"animegan_{pt.stem}.onnx"
        build(sd, str(out))
        print(f"변환 완료: {out.name}  ({out.stat().st_size/1e6:.1f} MB)")
