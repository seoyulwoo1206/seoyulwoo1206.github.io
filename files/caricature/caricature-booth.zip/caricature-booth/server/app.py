"""
캐리커처 부스 서버 (FastAPI)

    python server/app.py          → http://localhost:8000

책 8장 '모델 서빙'의 주문형(on-demand) 서빙 구조:
  - 모델은 서버가 켜질 때 한 번만 메모리에 올린다 (매 요청마다 불러오면 느림)
  - 요청은 대기열(queue)에 넣고, 작업자 스레드가 하나씩 처리한다
  - 화면은 /api/jobs/{id}를 주기적으로 물어봐서 단계별 결과를 받아간다
"""
import json
import queue
import random
import shutil
import threading
import time
import uuid
from pathlib import Path

import cv2
import uvicorn
from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse, Response
from fastapi.staticfiles import StaticFiles

from pipeline import STEPS, FaceNotFound, Pipeline, remote
from pipeline.config import DATA, DEFAULT_STRENGTH, MAX_STRENGTH, ROOT, STYLES

JOBS_DIR = DATA / "jobs"
GALLERY_DIR = DATA / "gallery"
GALLERY_JSON = GALLERY_DIR / "gallery.json"
KEEP_MINUTES = 30  # 원본 사진이 들어 있는 작업 폴더는 30분 뒤 자동 삭제

for d in (JOBS_DIR, GALLERY_DIR):
    d.mkdir(parents=True, exist_ok=True)

app = FastAPI(title="머신러닝 캐리커처 부스")
jobs: dict[str, dict] = {}
work_q: "queue.Queue[str]" = queue.Queue()
lock = threading.Lock()

print("모델을 불러오는 중...")
pipe = Pipeline()
pipe.warmup()
print("준비 완료!")


# ---------------------------------------------------------------------------
# 갤러리 (퀴즈용) — 동의한 사람의 '캐리커처'와 닉네임만 저장
# ---------------------------------------------------------------------------
def load_gallery():
    if GALLERY_JSON.exists():
        return json.loads(GALLERY_JSON.read_text(encoding="utf-8"))
    return []


def save_gallery(items):
    GALLERY_JSON.write_text(json.dumps(items, ensure_ascii=False, indent=1), encoding="utf-8")


def add_to_gallery(job_id, nickname):
    shutil.copy(JOBS_DIR / job_id / "stylize.png", GALLERY_DIR / f"{job_id}.png")
    with lock:
        items = load_gallery()
        items.append({"id": job_id, "nickname": nickname, "time": time.time()})
        save_gallery(items)


# ---------------------------------------------------------------------------
# 작업자: 대기열에서 하나씩 꺼내 파이프라인 실행
# ---------------------------------------------------------------------------
def cleanup_old_jobs():
    now = time.time()
    for jid, job in list(jobs.items()):
        if now - job["created"] > KEEP_MINUTES * 60:
            shutil.rmtree(JOBS_DIR / jid, ignore_errors=True)
            jobs.pop(jid, None)


def worker():
    while True:
        jid = work_q.get()
        job = jobs.get(jid)
        if not job:
            continue
        job["status"] = "running"
        job["started"] = time.time()

        def on_step(key, filename, ms):
            job["steps"].append({"key": key, "file": f"/files/{jid}/{filename}", "ms": ms})

        try:
            res = pipe.run(job.pop("photo"), job["style"], job["strength"], JOBS_DIR / jid, on_step=on_step, glasses=job["glasses"], beauty=1.0 if job["beauty"] else 0.0, retouch_amount=1.0 if job["beauty"] else 0.0)
            job.update(res)
            job["status"] = "done"
            job["total_ms"] = round((time.time() - job["started"]) * 1000)
            if job["consent"] and job["nickname"]:
                add_to_gallery(jid, job["nickname"])
        except FaceNotFound as e:
            job.update(status="error", error=str(e))
        except Exception as e:  # 부스 운영 중 서버가 죽지 않도록
            job.update(status="error", error=f"처리 중 문제가 생겼어요: {e}")
        finally:
            work_q.task_done()


threading.Thread(target=worker, daemon=True).start()


# ---------------------------------------------------------------------------
# API
# ---------------------------------------------------------------------------
@app.get("/api/config")
def config():
    return {
        "styles": [{"key": k, "name": n, "desc": d} for k, _, n, d in STYLES],
        "steps": [{"key": k, "title": t, "desc": d} for k, t, d in STEPS],
        "strength": {"default": DEFAULT_STRENGTH, "min": 1.0, "max": MAX_STRENGTH},
    }


@app.get("/api/remote")
def remote_status():
    """AI 서버(Colab) 연결 상태"""
    url = remote.get_url()
    ok, info = remote.health(url)
    return {"url": url, "ok": ok, "info": info}


@app.post("/api/remote")
def remote_set(url: str = Form("")):
    url = remote.set_url(url)
    ok, info = remote.health(url)
    return {"url": url, "ok": ok, "info": info}


# ---- 폰으로 찍기 (Colab 서버를 거쳐 사진을 받아온다)
@app.get("/api/phone/start")
def phone_start():
    try:
        pid, link = remote.phone_state()
        return {"ok": True, "id": pid, "link": link}
    except remote.RemoteError as e:
        return {"ok": False, "info": str(e)}


@app.get("/api/phone/qr")
def phone_qr():
    """폰에서 열 주소를 QR 코드(PNG)로"""
    url = remote.get_url()
    if not url:
        raise HTTPException(404, "AI 서버 주소가 없어요")
    qr = cv2.QRCodeEncoder_create().encode(url + "/phone")
    qr = cv2.copyMakeBorder(qr, 4, 4, 4, 4, cv2.BORDER_CONSTANT, value=255)        # 흰 여백이 있어야 잘 읽힌다
    qr = cv2.resize(qr, None, fx=8, fy=8, interpolation=cv2.INTER_NEAREST)
    return Response(cv2.imencode(".png", qr)[1].tobytes(), media_type="image/png", headers={"Cache-Control": "no-store"})


@app.get("/api/phone/poll")
def phone_poll(after: int = 0):
    got = remote.phone_latest(after)
    if not got:
        return Response(status_code=204)
    return Response(got[1], media_type="image/jpeg", headers={"X-Photo-Id": str(got[0]), "Cache-Control": "no-store"})


@app.post("/api/jobs")
async def create_job(
    photo: UploadFile = File(...),
    style: str = Form("paint"),
    strength: float = Form(DEFAULT_STRENGTH),
    nickname: str = Form(""),
    consent: bool = Form(False),
    glasses: bool = Form(False),
    beauty: bool = Form(True),
):
    if style not in {k for k, *_ in STYLES}:
        raise HTTPException(400, "알 수 없는 스타일")
    data = await photo.read()
    if len(data) > 15 * 1024 * 1024:
        raise HTTPException(400, "사진이 너무 커요 (15MB 이하)")
    cleanup_old_jobs()
    jid = uuid.uuid4().hex[:10]
    jobs[jid] = {
        "id": jid, "status": "queued", "created": time.time(), "photo": data,
        "style": style, "strength": max(1.0, min(MAX_STRENGTH, strength)),
        "nickname": nickname.strip()[:12], "consent": consent, "glasses": glasses, "beauty": beauty, "steps": [],
    }
    work_q.put(jid)
    return {"id": jid}


@app.get("/api/jobs/{jid}")
def job_status(jid: str):
    job = jobs.get(jid)
    if not job:
        raise HTTPException(404, "없는 작업이에요")
    out = {k: v for k, v in job.items() if k != "photo"}
    if job["status"] == "queued":
        waiting = [j for j in jobs.values() if j["status"] == "queued" and j["created"] < job["created"]]
        out["ahead"] = len(waiting) + sum(1 for j in jobs.values() if j["status"] == "running")
    return out


@app.get("/files/{jid}/{name}")
def job_file(jid: str, name: str):
    path = (JOBS_DIR / jid / name).resolve()
    if not str(path).startswith(str(JOBS_DIR.resolve())) or not path.exists():
        raise HTTPException(404)
    return FileResponse(path, headers={"Cache-Control": "no-store"})


@app.get("/api/gallery")
def gallery():
    return [{"id": g["id"], "nickname": g["nickname"], "img": f"/gallery/{g['id']}.png"} for g in load_gallery()]


@app.get("/gallery/{name}")
def gallery_file(name: str):
    path = (GALLERY_DIR / name).resolve()
    if path.parent != GALLERY_DIR.resolve() or not path.exists():
        raise HTTPException(404)
    return FileResponse(path)


@app.get("/api/quiz")
def quiz(exclude: str = ""):
    """앞서 다녀간 친구의 캐리커처 1장 + 닉네임 보기 4개"""
    allg = load_gallery()
    items = [g for g in allg if g["id"] != exclude]  # 방금 내 캐리커처는 문제로 안 냄
    names = list({g["nickname"] for g in allg})       # 보기에는 나를 포함한 모두
    if not items or len(names) < 2:
        return {"ready": False}
    ans = random.choice(items)
    others = random.sample([n for n in names if n != ans["nickname"]], k=min(3, len(names) - 1))
    choices = others + [ans["nickname"]]
    random.shuffle(choices)
    return {"ready": True, "img": f"/gallery/{ans['id']}.png", "choices": choices, "answer": ans["nickname"]}


@app.delete("/api/gallery/{gid}")
def gallery_delete(gid: str):
    """본인이 원하면 갤러리에서 지우기 (운영자용)"""
    with lock:
        items = [g for g in load_gallery() if g["id"] != gid]
        save_gallery(items)
    (GALLERY_DIR / f"{gid}.png").unlink(missing_ok=True)
    return {"ok": True}


app.mount("/", StaticFiles(directory=ROOT / "web", html=True), name="web")

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
