"""
③ 과장: '평균 얼굴과 다른 부분'을 더 다르게 만든다 (캐리커처의 원리)

    새 위치 = 평균 위치 + 강도 × (내 위치 - 평균 위치)

캐리커처 작가처럼 '가장 튀는 특징 2개'만 세게, 나머지는 살짝만 과장한다.
그다음 468개 점을 따라 이미지를 매끄러운 곡면(Thin-Plate Spline)으로 변형한다.
마지막으로 머리를 몸보다 조금 크게 (빅헤드 구도).
"""
import cv2
import numpy as np

from .config import MODELS
from .landmarks import EYE_L, EYE_R, FEATURE_GROUPS, PARTS, compare, group_labels, to68

MEAN_FACE = np.load(MODELS / "mean_face_468.npy").astype(np.float32)   # MediaPipe 표준 얼굴 (정면·무표정)

MILD = 0.35       # 튀지 않는 부위는 강도의 35%만 적용
JAW_FRAC = 1.0    # 턱선·얼굴 윤곽은 항상 전체 강도로 과장 (얼굴형이 캐리커처의 핵심)
MAX_MOVE = 0.22   # 한 점이 움직일 수 있는 최대 거리 (두 눈 사이 거리 기준 비율)
SMOOTH_SIGMA = 0.25  # 이동량을 부드럽게 퍼뜨리는 반경 (두 눈 사이 거리 기준 비율)
SHRINK_FRAC = 0.5   # 줄어드는 방향 과장은 이 비율만 (1.0 = 키우는 쪽과 똑같이)
GLOBAL_FRAC = 0.25       # 얼굴 전체 비율(길이·너비) 과장 — 기본 평균(서양 성인 기준)일 땐 약하게만 (찌부 방지)
BEAUTY_EYE = 0.20        # 미화: 눈 크기 +20% (강도 1.5 기준, 강도 따라 더 커짐)
BEAUTY_JAW = 0.14        # 미화: 턱선을 가운데로 14% (V라인)
BEAUTY_CHIN = 0.05       # 미화: 턱끝 살짝 아래로 (얼굴 길어 보이게)
BEAUTY_NOSE = 0.07       # 미화: 코는 살짝 작게 (한국식 캐리커처 문법: 눈 크게, 코·입 작게)
K_GAIN = 1.6             # 슬라이더 강도 k → 실제 특징 배율 1+(k-1)×K_GAIN (슬라이더 차이가 잘 느껴지게)
GLOBAL_FRAC_BOOTH = 0.6  # '우리 부스 평균 얼굴'(6명 이상)이 기준이 되면 이만큼 켬 → 둥근/긴/넓은 얼굴형이 과장됨
MAX_MOVE_JAW = 0.32      # 턱선 점은 조금 더 멀리 움직일 수 있음
TPS_REG = 30.0    # 곡면 변형의 매끄러움 (클수록 점을 정확히 통과하기보다 부드럽게)
EXPRESSION = ("eye_r", "eye_l", "mouth")      # 세로(뜬 정도)는 과장하지 않는 부위
GLASSES_FIXED = ("eye_r", "eye_l", "brow")    # 안경 쓰면 아예 고정하는 부위


def align_to(ref, p):
    """기준 얼굴(ref)을 내 얼굴 p 위치·크기·각도에 맞춘다 (닮음 변환: 비율은 그대로)"""
    M, _ = cv2.estimateAffinePartial2D(ref, p, method=cv2.LMEDS)
    return (ref @ M[:, :2].T + M[:, 2]).astype(np.float32)


def align_affine(ref, p):
    """기준 얼굴을 내 얼굴의 전체 비율(길이·너비)까지 맞춘다 (아핀 변환).
    이걸 기준으로 삼으면 '얼굴이 전체적으로 짧다/넓다' 같은 비율 차이는 빠지고,
    눈·코·입·턱선의 '모양' 차이만 남는다."""
    M, _ = cv2.estimateAffine2D(ref, p, method=cv2.LMEDS)
    return (ref @ M[:, :2].T + M[:, 2]).astype(np.float32)


def normalize_shape(p):
    """부스 평균 얼굴을 만들기 위해 모양만 남기고 위치·크기·각도를 없앤다"""
    return align_to(p, MEAN_FACE)


def per_point_strength(p, ref_a, k, labels, top_n=2):
    """점별 강도: 평균과 가장 많이 다른 특징 top_n에 속한 부위는 k, 나머지는 약하게.
    턱선·얼굴 윤곽은 캐리커처의 핵심이라 항상 JAW_FRAC 만큼은 과장한다."""
    diffs = sorted(compare(to68(p), to68(ref_a)), key=lambda m: -abs(m["diff"]))
    strong_groups = set()
    for m in diffs[:top_n]:
        strong_groups.update(FEATURE_GROUPS[m["key"]])
    ks = np.full((len(p), 1), 1.0 + (k - 1.0) * MILD, np.float32)
    ks[labels == "jaw"] = 1.0 + (k - 1.0) * JAW_FRAC
    ks[np.isin(labels, list(strong_groups))] = k
    return ks, [m["key"] for m in diffs[:top_n]]


def k_scale(k):
    """강도 k → 한도·미화 배율 (k=1.0: 0.4배, 1.5: 1배, 2.4: 2배쯤). 슬라이더 차이가 눈에 보이게"""
    return max(0.3, 0.4 + 1.2 * (k - 1.0))


def beautify_points(p, q, labels, amount=1.0):
    """미화: 눈은 중심 기준으로 키우고, 코는 살짝 작게, 턱선은 얼굴 중심선 쪽으로 모아 V라인으로"""
    if amount <= 0:
        return q
    q = q.copy()
    p68 = to68(p)
    iod = np.linalg.norm(p68[EYE_L].mean(0) - p68[EYE_R].mean(0))
    for g in ("eye_r", "eye_l"):
        idx = np.where(labels == g)[0]
        if len(idx):
            c = q[idx].mean(0)
            q[idx] = c + (q[idx] - c) * (1 + BEAUTY_EYE * amount)
    nose = np.where(labels == "nose")[0]
    if len(nose):
        c = q[nose].mean(0)
        q[nose] = c + (q[nose] - c) * (1 - BEAUTY_NOSE * min(amount, 1.5))
    jaw = np.where(labels == "jaw")[0]
    if len(jaw):
        cx = p68[[27, 30, 33, 8], 0].mean()                 # 얼굴 중심선 x
        eye_y = p68[EYE_R + EYE_L, 1].mean()
        chin_y = p68[8, 1]
        t = np.clip((q[jaw, 1] - eye_y) / max(chin_y - eye_y, 1), 0, 1)   # 눈높이 0 → 턱끝 1
        q[jaw, 0] -= (q[jaw, 0] - cx) * BEAUTY_JAW * amount * t           # 아래로 갈수록 더 모음
        q[jaw, 1] += BEAUTY_CHIN * amount * iod * t ** 2                   # 턱끝은 살짝 아래로
    return q


def exaggerate_points(p, ref, k, glasses=False, global_frac=GLOBAL_FRAC, beauty=0.0):
    k_ui = k
    k = 1.0 + (k - 1.0) * K_GAIN
    labels = group_labels(p)
    ref_sim = align_to(ref, p)        # 비율까지 비교하는 기준 (화면 표시용)
    ref_a = align_affine(ref, p)      # 전체 비율은 맞춘 기준 → 국소 특징만 과장
    ks, strong = per_point_strength(p, ref_a, k, labels)

    # 줄이는 쪽(부위 중심으로 모이는 이동)은 강도를 절반만: 눈·입이 쪼그라들어 찌부되는 것 방지
    dev = p - ref_a
    shrink = np.zeros(len(p), bool)
    for g in np.unique(labels):
        idx = np.where(labels == g)[0]
        c = p[idx].mean(0)
        radial = p[idx] - c
        shrink[idx] = (dev[idx] * radial).sum(1) < 0
    ks = np.where(shrink[:, None], 1.0 + (ks - 1.0) * SHRINK_FRAC, ks)

    # 전체 비율(길이·너비) 차이는 GLOBAL_FRAC 만큼만 과장 (기본 0 = 과장 안 함)
    q = ref_a + ks * dev + global_frac * (k - 1.0) * (ref_a - ref_sim)

    # 눈·입: 위치와 너비(가로)만 과장하고, 뜬 정도(세로)는 원래 표정 그대로 둔다
    # (평균 얼굴은 무표정이라, 웃으며 눈을 찡그린 사진을 '눈이 작은 사람'으로 착각하기 때문)
    for g in EXPRESSION:
        idx = np.where(labels == g)[0]
        if len(idx) == 0:
            continue
        kg = float(ks[idx[0], 0])
        c_p, c_r = p[idx].mean(0), ref_a[idx].mean(0)
        shape_p, shape_r = p[idx] - c_p, ref_a[idx] - c_r
        new_c = c_r + kg * (c_p - c_r)
        new_shape = shape_r + (shape_p - shape_r) * np.array([kg, 1.0], np.float32)
        q[idx] = new_c + new_shape

    # 미화 (눈 키우기·코 작게·V라인) — 강도에 비례, 안경이면 눈은 건드리지 않음
    q = beautify_points(p, q, labels, beauty * k_scale(k_ui))

    # 안경을 썼으면 눈·눈썹 주변은 건드리지 않는다 (안경알이 찌그러지는 것 방지)
    if glasses:
        fixed = np.isin(labels, list(GLASSES_FIXED))
        q[fixed] = p[fixed]

    # 너무 멀리 움직이는 점은 한도에서 자른다 (괴상한 얼굴 방지)
    p68 = to68(p)
    iod = np.linalg.norm(p68[EYE_L].mean(0) - p68[EYE_R].mean(0))
    move = smooth_field(p, q - p, SMOOTH_SIGMA * iod)   # 옆 점끼리 들쭉날쭉하지 않게 이동량을 부드럽게
    dist = np.linalg.norm(move, axis=1, keepdims=True)
    cap = np.where((labels == "jaw")[:, None], MAX_MOVE_JAW, MAX_MOVE) * iod * k_scale(k_ui)
    q = p + move * np.minimum(1.0, cap / np.maximum(dist, 1e-6))

    # 얼굴 중심이 원래 자리에 오도록
    q += p.mean(0) - q.mean(0)
    return q.astype(np.float32), ref_a, strong


def smooth_field(p, move, sigma):
    """각 점의 이동량을 주변 점들의 이동량과 가우시안 가중 평균 (잔물결·울퉁불퉁 방지)"""
    d2 = ((p[:, None, :] - p[None, :, :]) ** 2).sum(-1)
    w = np.exp(-d2 / (2 * sigma * sigma))
    return (w @ move) / w.sum(1, keepdims=True)


def _anchors(p, size):
    """얼굴 바깥 고정점: 얼굴 주변 고리 + 이미지 가장자리 (여기는 움직이지 않음)"""
    c = p.mean(0)
    r = np.linalg.norm(p - c, axis=1).max() * 1.7
    ring = np.stack([c + r * np.array([np.cos(t), np.sin(t)]) for t in np.linspace(0, 2 * np.pi, 24, endpoint=False)])
    s = size - 1
    border = np.array([[0, 0], [s / 2, 0], [s, 0], [s, s / 2], [s, s], [s / 2, s], [0, s], [0, s / 2]], np.float32)
    return np.clip(np.vstack([ring, border]), 0, s).astype(np.float32)


class TPS:
    """Thin-Plate Spline: 점 몇 개의 이동을 매끄러운 곡면으로 퍼뜨린다 (책의 '보간' 개념)"""

    def __init__(self, src, dst, reg=1e-3):
        n = len(src)
        K = self._kernel(src, src) + reg * np.eye(n)
        P = np.hstack([np.ones((n, 1)), src])
        A = np.zeros((n + 3, n + 3))
        A[:n, :n], A[:n, n:], A[n:, :n] = K, P, P.T
        b = np.zeros((n + 3, 2))
        b[:n] = dst
        self.src = src
        self.w = np.linalg.solve(A, b)

    @staticmethod
    def _kernel(a, b):
        r2 = ((a[:, None, :] - b[None, :, :]) ** 2).sum(-1)
        return np.where(r2 > 0, r2 * np.log(r2 + 1e-12) / 2, 0.0)

    def __call__(self, pts):
        n = len(self.src)
        K = self._kernel(pts, self.src)
        P = np.hstack([np.ones((len(pts), 1)), pts])
        return K @ self.w[:n] + P @ self.w[n:]


def warp_tps(img, src_pts, dst_pts, grid=64):
    """src 점이 dst 위치로 가도록 이미지를 변형. 거친 격자에서 TPS를 계산하고 확대해서 빠르게."""
    h, w = img.shape[:2]
    # 픽셀 단위로 역방향 매핑: 결과 픽셀(dst) → 원본 픽셀(src)
    tps = TPS(dst_pts.astype(np.float64), src_pts.astype(np.float64), reg=TPS_REG)
    gy, gx = np.mgrid[0:grid, 0:grid]
    g = np.stack([gx.ravel() * (w - 1) / (grid - 1), gy.ravel() * (h - 1) / (grid - 1)], 1)
    m = tps(g).reshape(grid, grid, 2).astype(np.float32)
    map_x = cv2.resize(m[..., 0], (w, h), interpolation=cv2.INTER_CUBIC)
    map_y = cv2.resize(m[..., 1], (w, h), interpolation=cv2.INTER_CUBIC)
    return cv2.remap(img, map_x, map_y, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)


def exaggerate(img, p, ref, k, glasses=False, extra=(), global_frac=GLOBAL_FRAC, beauty=0.0):
    """이미지와 함께 변형할 다른 배열(마스크 등)도 extra로 넘기면 같은 변형을 적용한다"""
    q, ref_a, strong = exaggerate_points(p, ref, k, glasses, global_frac, beauty)
    anchors = _anchors(p, img.shape[0])
    src = np.vstack([p, anchors])
    dst = np.vstack([q, anchors])
    outs = [warp_tps(x, src, dst) for x in (img, *extra)]
    return outs, q, ref_a, strong


def bighead_scale(base, k):
    """강도에 따라 빅헤드 정도도 달라진다 (k=1.5에서 base, 2.4에서 약 1.6배)"""
    return 1.0 + (base - 1.0) * max(0.4, 0.4 + 1.2 * (k - 1.0)) / 1.0


def bighead_fit(mask, p68, scale, margin=0.03):
    """머리가 화면 밖으로 잘리지 않도록 빅헤드 배율을 줄인다"""
    if scale <= 1.0:
        return scale
    h, w = mask.shape[:2]
    ys, xs = np.where(mask > 0.5)
    chin_y = p68[8, 1]
    head = ys < chin_y
    if head.sum() == 0:
        return scale
    ys, xs = ys[head], xs[head]
    cx, cy = float(p68[30, 0]), float(p68[30, 1])
    lim = scale
    for v, c, lo, hi in ((ys.min(), cy, margin * h, None), (xs.min(), cx, margin * w, None),
                         (xs.max(), cx, None, (1 - margin) * w), (ys.max(), cy, None, (1 - margin) * h)):
        d = v - c
        if abs(d) < 1:
            continue
        bound = lo if lo is not None else hi
        lim = min(lim, (bound - c) / d) if (bound - c) / d > 0 else lim
    return float(max(1.0, min(scale, lim)))


def bighead(img, mask, p68, scale=1.14):
    """인터넷 캐리커처의 시그니처: 머리는 크게, 몸은 그대로 (배경이 지워진 사진에 적용)"""
    if scale <= 1.0:
        return img
    h, w = img.shape[:2]
    iod = np.linalg.norm(p68[EYE_L].mean(0) - p68[EYE_R].mean(0))
    chin_y = p68[8, 1]
    ys = np.arange(h, dtype=np.float32)[:, None]
    fade = np.clip((chin_y + 0.35 * iod - ys) / (0.5 * iod), 0, 1)   # 턱 아래로 부드럽게 사라지는 머리 마스크
    head_m = (mask * fade).astype(np.float32)
    cx, cy = float(p68[30, 0]), float(p68[30, 1])                       # 코끝 기준으로 확대
    M = np.array([[scale, 0, cx * (1 - scale)], [0, scale, cy * (1 - scale)]], np.float32)
    big = cv2.warpAffine(img, M, (w, h), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REPLICATE)
    big_m = cv2.warpAffine(head_m, M, (w, h), flags=cv2.INTER_LINEAR)[..., None]
    return (big * big_m + img * (1 - big_m)).astype(np.uint8)


def bighead_points(p68, scale=1.14):
    """bighead와 같은 변환을 점에도 적용 (코끝 기준 확대)"""
    if scale <= 1.0:
        return p68
    c = (to68(p68) if len(p68) == 468 else p68)[30]
    return (c + (p68 - c) * scale).astype(np.float32)


def draw_compare(img, p468, ref_a468):
    """평균 얼굴(하늘색) 위에 내 얼굴(주황)을 겹쳐 그리기"""
    v = (img * 0.55 + 255 * 0.45).astype(np.uint8)
    mine, ref_a = to68(p468), to68(ref_a468)
    for pts, col, th in [(ref_a, (255, 189, 120), 2), (mine, (40, 120, 255), 2)]:
        for idx, closed in PARTS[:-1]:
            cv2.polylines(v, [pts[idx].astype(np.int32)], closed, col, th, cv2.LINE_AA)
    for a, b in zip(ref_a, mine):
        if np.linalg.norm(a - b) > 3:
            cv2.arrowedLine(v, tuple(a.astype(int)), tuple(b.astype(int)), (60, 60, 60), 1, cv2.LINE_AA, tipLength=0.4)
    return v
