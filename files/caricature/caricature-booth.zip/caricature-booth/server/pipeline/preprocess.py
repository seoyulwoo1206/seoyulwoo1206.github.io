"""
① 전처리: 얼굴 찾기 → 기울기 바로잡기 → 자르기 → 배경 지우기

- 얼굴 검출: YuNet (OpenCV, 0.2MB 초경량 CNN)
- 배경 분리: U^2-Net(p) (4.6MB 경량 분할 모델)
"""
import cv2
import numpy as np
import onnxruntime as ort

from .config import MODELS, OUT_SIZE, BG_COLOR, MIN_FACE_PX, CARD_BG, STICKER_BORDER


class FaceNotFound(Exception):
    pass


def load_image(data: bytes) -> np.ndarray:
    """업로드된 바이트 → BGR 이미지 (휴대폰 사진 회전 정보 반영)"""
    arr = np.frombuffer(data, np.uint8)
    img = cv2.imdecode(arr, cv2.IMREAD_COLOR)  # EXIF 회전은 imdecode가 처리
    if img is None:
        raise ValueError("이미지를 읽을 수 없어요.")
    # 너무 큰 사진은 줄여서 처리 속도 확보
    h, w = img.shape[:2]
    s = 1600 / max(h, w)
    if s < 1:
        img = cv2.resize(img, None, fx=s, fy=s, interpolation=cv2.INTER_AREA)
    return img


class FaceAligner:
    def __init__(self):
        self.det = cv2.FaceDetectorYN.create(
            str(MODELS / "face_detection_yunet_2023mar.onnx"), "", (320, 320), 0.6, 0.3, 5000
        )

    def detect(self, img):
        """가장 큰 얼굴 1개: [x, y, w, h, 오른눈x,y, 왼눈x,y, 코x,y, 입오른x,y, 입왼x,y, score]"""
        sc = 640 / max(img.shape[:2])
        small = cv2.resize(img, None, fx=sc, fy=sc, interpolation=cv2.INTER_AREA)
        self.det.setInputSize((small.shape[1], small.shape[0]))
        _, faces = self.det.detect(small)
        if faces is None or len(faces) == 0:
            raise FaceNotFound("얼굴을 찾지 못했어요. 정면을 보고 다시 찍어주세요.")
        # 주변 사람 무시: 화면 가운데에 가깝고 큰 얼굴을 '주인공'으로 고른다
        H, W = small.shape[:2]
        def score(r):
            cx, cy = r[0] + r[2] / 2, r[1] + r[3] / 2
            d = np.hypot((cx - W / 2) / W, (cy - H / 2) / H)   # 중심에서 떨어진 정도 (0~0.7)
            return r[2] * r[3] * np.exp(-6 * d)
        f = max(faces, key=score).copy()
        f[:14] /= sc
        if f[2] < MIN_FACE_PX:
            raise FaceNotFound("얼굴이 너무 작게 찍혔어요. 카메라에 더 가까이 와서 다시 찍어주세요.")
        return f

    def align_crop(self, img, face):
        """두 눈이 수평이 되도록 회전 + 머리·어깨가 들어가게 정사각형으로 자르기"""
        x, y, w, h = face[:4]
        eye_r, eye_l = face[4:6], face[6:8]
        ang = np.degrees(np.arctan2(eye_l[1] - eye_r[1], eye_l[0] - eye_r[0]))
        cx, cy = x + w / 2, y + h / 2
        side = max(w, h) * 2.3
        # 얼굴이 카메라에 너무 가까워 머리 위가 잘리면, 잘리지 않는 선까지만 넓게 잡는다 (납작머리 방지)
        side = float(max(min(side, cy / 0.47), max(w, h) * 1.7))
        # 얼굴 중심을 기준으로 회전 + 확대 + 이동을 한 번에 (아핀 변환)
        scale = OUT_SIZE / side
        M = cv2.getRotationMatrix2D((float(cx), float(cy)), float(ang), scale)
        M[0, 2] += OUT_SIZE / 2 - cx
        M[1, 2] += OUT_SIZE * 0.47 - cy
        # 사진 밖 영역은 배경색으로 채운다 (가장자리 픽셀을 늘이면 줄무늬가 생김)
        crop = cv2.warpAffine(img, M, (OUT_SIZE, OUT_SIZE), flags=cv2.INTER_CUBIC,
                              borderMode=cv2.BORDER_CONSTANT, borderValue=BG_COLOR)
        # 원본 얼굴 박스를 잘라낸 좌표계로 옮겨두기 (특징점 검출에 사용)
        c = M @ np.array([cx, cy, 1.0])
        box = (c[0], c[1], w * scale, h * scale)
        return crop, box, M


class BackgroundRemover:
    """U^2-Net(p): 사진에서 '주인공(사람)'만 남기는 분할(segmentation) 모델"""

    def __init__(self):
        self.sess = ort.InferenceSession(str(MODELS / "u2netp.onnx"), providers=["CPUExecutionProvider"])
        self.inp = self.sess.get_inputs()[0].name

    def mask(self, img_bgr):
        rgb = cv2.cvtColor(cv2.resize(img_bgr, (320, 320), interpolation=cv2.INTER_AREA), cv2.COLOR_BGR2RGB)
        x = rgb.astype(np.float32) / max(rgb.max(), 1)
        x = (x - [0.485, 0.456, 0.406]) / [0.229, 0.224, 0.225]
        x = x.transpose(2, 0, 1)[None].astype(np.float32)
        d = self.sess.run(None, {self.inp: x})[0][0, 0]
        d = (d - d.min()) / (d.max() - d.min() + 1e-8)
        m = cv2.resize(d, (img_bgr.shape[1], img_bgr.shape[0]), interpolation=cv2.INTER_LINEAR)
        m = np.clip((m - 0.15) / 0.7, 0, 1).astype(np.float32)
        # 가이디드 필터: 320px짜리 거친 마스크를 원본 사진의 경계(머리카락 등)에 맞춰 정밀하게
        try:
            r = max(4, img_bgr.shape[0] // 128)
            m = cv2.ximgproc.guidedFilter(img_bgr, m, r, 1e-3)
        except Exception:
            m = cv2.GaussianBlur(m, (0, 0), 1.5)
        return np.clip(m, 0, 1)

    @staticmethod
    def keep_main_person(m, box):
        """마스크에서 주인공 얼굴과 이어진 덩어리만 남긴다 (옆에 서 있는 사람 제거)"""
        cx, cy, w, h = box
        binary = (m > 0.5).astype(np.uint8)
        n, labels = cv2.connectedComponents(binary)
        if n <= 2:
            return m
        # 얼굴 박스 안에서 가장 많이 보이는 덩어리 번호
        y0, y1 = int(max(cy - h / 2, 0)), int(min(cy + h / 2, m.shape[0]))
        x0, x1 = int(max(cx - w / 2, 0)), int(min(cx + w / 2, m.shape[1]))
        inside = labels[y0:y1, x0:x1]
        inside = inside[inside > 0]
        if inside.size == 0:
            return m
        main = np.bincount(inside).argmax()
        keep = (labels == main).astype(np.float32)
        keep = cv2.GaussianBlur(keep, (0, 0), 2)
        return m * keep

    def apply(self, img_bgr, m):
        bg = np.full_like(img_bgr, BG_COLOR, dtype=np.uint8)
        a = m[..., None]
        return (img_bgr * a + bg * (1 - a)).astype(np.uint8)


def _heart(canvas, cx, cy, r, color, rough=0.12, seed=0):
    """손으로 그린 듯한 하트 (살짝 삐뚤게)"""
    rng = np.random.default_rng(seed)
    t = np.linspace(0, 2 * np.pi, 48)
    x = 16 * np.sin(t) ** 3
    y = -(13 * np.cos(t) - 5 * np.cos(2 * t) - 2 * np.cos(3 * t) - np.cos(4 * t))
    pts = np.stack([x, y], 1) / 17.0 * r
    pts = pts * (1 + rng.normal(0, rough, (len(t), 1)))
    ang = rng.uniform(-0.35, 0.35); c, s_ = np.cos(ang), np.sin(ang)
    pts = pts @ np.array([[c, -s_], [s_, c]], np.float32)
    pts = (pts + [cx, cy]).astype(np.int32).reshape(-1, 1, 2)
    cv2.fillPoly(canvas, [pts], color, cv2.LINE_AA)
    cv2.polylines(canvas, [pts], True, tuple(int(v * 0.75) for v in color), max(1, r // 12), cv2.LINE_AA)


def compose_paper(img, m, hearts=True):
    """손그림 캐리커처용: 흰 종이 + 종이 결 + 사람 주변 분홍 하트 (스티커 테두리 없음)"""
    h, w = img.shape[:2]
    m = np.clip(m, 0, 1).astype(np.float32)
    rng = np.random.default_rng(h + w)
    paper = np.full((h, w, 3), 251, np.float32)
    n1 = cv2.GaussianBlur(rng.random((h, w), dtype=np.float32), (0, 0), 1.0)
    n2 = cv2.GaussianBlur(rng.random((h, w), dtype=np.float32), (0, 0), 6.0)
    paper = paper * (1 + 0.035 * (n1 - 0.5) * 3 + 0.03 * (n2 - 0.5) * 3)[..., None]
    paper = np.clip(paper, 0, 255).astype(np.uint8)
    if hearts:
        far = cv2.distanceTransform((m < 0.5).astype(np.uint8), cv2.DIST_L2, 5)
        cols = [(150, 120, 255), (120, 100, 245), (180, 150, 255)]
        placed = []
        for i in range(40):
            r = int(rng.integers(w // 28, w // 14))
            cx, cy = int(rng.integers(r, w - r)), int(rng.integers(r, h - r))
            if far[cy, cx] < r * 1.6 or any(np.hypot(cx - px, cy - py) < (r + pr) * 1.6 for px, py, pr in placed):
                continue
            _heart(paper, cx, cy, r, cols[i % 3], seed=i)
            placed.append((cx, cy, r))
            if len(placed) >= 7:
                break
    hard = (m > 0.5).astype(np.uint8)
    sh = cv2.GaussianBlur(hard.astype(np.float32), (0, 0), w / 100)
    off = max(2, w // 200)
    shadow = np.zeros_like(sh); shadow[off:, off:] = sh[:-off, :-off]
    out = paper.astype(np.float32) * (1 - 0.18 * shadow[..., None])
    out = out * (1 - m[..., None]) + img.astype(np.float32) * m[..., None]
    return np.clip(out, 0, 255).astype(np.uint8)


def compose_card(img, m):
    """최종 합성: 은은한 그라데이션 배경 + 사람 주변 흰 스티커 테두리 + 그림자 (다이컷 스티커 느낌)"""
    h, w = img.shape[:2]
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    d = np.sqrt(((xx - w / 2) / w) ** 2 + ((yy - h * 0.45) / h) ** 2) / 0.7
    d = np.clip(d, 0, 1)[..., None]
    c0, c1 = np.array(CARD_BG[0], np.float32), np.array(CARD_BG[1], np.float32)
    bg = c0 * (1 - d) + c1 * d
    m = np.clip(m, 0, 1).astype(np.float32)
    hard = (m > 0.5).astype(np.uint8)
    k = max(3, int(w * STICKER_BORDER) | 1)
    border = cv2.dilate(hard, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k))).astype(np.float32)
    border = cv2.GaussianBlur(border, (0, 0), 1.0)
    # 그림자: 테두리를 살짝 오른쪽 아래로 밀고 흐리게
    sh = np.zeros_like(border)
    off = max(2, w // 170)
    sh[off:, off:] = border[:-off, :-off]
    sh = cv2.GaussianBlur(sh, (0, 0), w / 120)
    out = bg * (1 - 0.35 * sh[..., None])
    out = out * (1 - border[..., None]) + 255.0 * border[..., None]           # 흰 스티커
    out = out * (1 - m[..., None]) + img.astype(np.float32) * m[..., None]    # 사람
    return np.clip(out, 0, 255).astype(np.uint8)


def _face_region(img, box, wf=0.3, y0f=-0.1, y1f=0.35):
    cx, cy, w, h = box
    x0, x1 = int(max(cx - w * wf, 0)), int(min(cx + w * wf, img.shape[1]))
    y0, y1 = int(max(cy + h * y0f, 0)), int(min(cy + h * y1f, img.shape[0]))
    return img[y0:y1, x0:x1]


def skin_noise(img, box):
    """코·볼 피부 영역의 고주파 성분 크기로 잡음을 추정 (피부는 원래 매끈해야 하니까)"""
    L = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)[..., 0].astype(np.float32)
    L = _face_region(L[..., None], box)[..., 0]
    if L.size < 100:
        return 0.0
    hp = L - cv2.GaussianBlur(L, (0, 0), 2.5)
    return float(np.median(np.abs(hp - np.median(hp)))) / 0.6745


def sharpness(img, box):
    """얼굴(눈~입 영역)의 선명도: 라플라시안 분산. 작게 찍혀 키운 얼굴은 값이 낮다."""
    g = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    r = _face_region(g[..., None], box, wf=0.45, y0f=-0.3, y1f=0.5)[..., 0]
    return float(cv2.Laplacian(r, cv2.CV_32F).var()) if r.size else 0.0


def denoise(img, box):
    """잡음 정제: 선명한 사진만 잡음을 지우고, 흐린 사진(작게 찍힌 얼굴)은 오히려 윤곽을 살린다."""
    sharp = sharpness(img, box)
    n = skin_noise(img, box)
    if sharp > 60 and n > 6.5:          # 선명하지만 잡음 많음 → 세게
        img = cv2.fastNlMeansDenoisingColored(img, None, 8, 8, 7, 21)
    elif sharp > 60 and n > 4.5:        # 보통
        img = cv2.fastNlMeansDenoisingColored(img, None, 4, 4, 7, 21)
    img = cv2.bilateralFilter(img, d=5, sigmaColor=20, sigmaSpace=4)
    if sharp < 120:                      # 흐린 얼굴 → 언샤프 마스크로 눈·입 윤곽 복원
        amount = float(np.clip((120 - sharp) / 120, 0.3, 0.8))
        blur = cv2.GaussianBlur(img, (0, 0), 1.6)
        img = cv2.addWeighted(img, 1 + amount, blur, -amount, 0)
    return img


def enhance_lighting(img, box):
    """조명 보정: '얼굴 피부' 밝기를 기준으로 맞춘다 (배경이 어둡다고 얼굴을 하얗게 날리지 않도록)."""
    x = img.astype(np.float32)
    face = _face_region(x, box)
    if face.size == 0:
        return img, 128.0
    # 1) 화이트밸런스: 얼굴 피부가 중립에 가깝도록 절반만 보정 (형광등 누런기·푸른기 제거)
    means = face.reshape(-1, 3).mean(0)
    gain = means.mean() / np.maximum(means, 1)
    x *= 1 + (gain - 1) * 0.4
    # 2) 뿌연 사진(역광·안개 낀 웹캠) 대비 복원: 얼굴의 어두운 곳(3%)→30, 밝은 곳(97%)→225 로 늘린다
    lab = cv2.cvtColor(np.clip(x, 0, 255).astype(np.uint8), cv2.COLOR_BGR2LAB).astype(np.float32)
    fL0 = _face_region(lab[..., :1], box)[..., 0]
    lo, hi = float(np.percentile(fL0, 3)), float(np.percentile(fL0, 97))
    if hi - lo < 150 and hi > lo + 5:
        gain = min((215.0 - 30.0) / (hi - lo), 3.0)
        lab[..., 0] = np.clip((lab[..., 0] - lo) * gain + 30.0, 0, 255)
        # 뿌옇면 색도 빠져 있으니 채도도 되살린다 (최대 1.6배)
        sat_gain = float(np.clip(1.0 + (gain - 1.0) * 0.5, 1.0, 1.6))
        wgt = np.clip((lab[..., :1] - 40.0) / 60.0, 0, 1)          # 어두운 픽셀(머리카락)은 채도 안 올림 → 파랗게 뜨는 것 방지
        lab[..., 1:] = np.clip((lab[..., 1:] - 128) * (1 + (sat_gain - 1) * wgt) + 128, 0, 255)
        x = cv2.cvtColor(lab.astype(np.uint8), cv2.COLOR_LAB2BGR).astype(np.float32)
    # 3) 노출: 얼굴 평균 밝기를 목표(150)로, 단 얼굴의 밝은 부분(97%)이 238을 넘지 않게
    L = cv2.cvtColor(np.clip(x, 0, 255).astype(np.uint8), cv2.COLOR_BGR2LAB)[..., 0].astype(np.float32)
    fL = _face_region(L[..., None], box)[..., 0]
    mean_l, hi_l = float(fL.mean()), float(np.percentile(fL, 97))
    target = 142.0
    gamma = 1.0
    if mean_l < target - 8 or mean_l > target + 20:
        gamma = float(np.clip(np.log(target / 255.0) / np.log(max(mean_l, 1) / 255.0), 0.55, 1.4))
        # 밝은 부분이 날아가면 감마를 되돌린다
        new_hi = 255.0 * (hi_l / 255.0) ** gamma
        if new_hi > 228 and gamma < 1.0:
            gamma = float(np.clip(np.log(228 / 255.0) / np.log(max(hi_l, 1) / 255.0), gamma, 1.0))
    if abs(gamma - 1.0) > 0.02:
        lut = (np.linspace(0, 1, 256) ** gamma * 255).astype(np.uint8)
        x = cv2.LUT(np.clip(x, 0, 255).astype(np.uint8), lut).astype(np.float32)
    return np.clip(x, 0, 255).astype(np.uint8), mean_l


def person_prior(mask, box):
    """머리(타원) + 어깨(아래로 넓어지는 사다리꼴) 영역만 사람으로 인정 → 옆 소품·물체 제거"""
    h, w = mask.shape
    cx, cy, bw, bh = box
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    # 머리: 얼굴 박스 중심에서 가로 1.15배, 세로 1.45배 반경의 타원 (머리카락 포함)
    rx, ry = bw * 1.15, bh * 1.45
    head = ((xx - cx) / rx) ** 2 + ((yy - (cy - bh * 0.15)) / ry) ** 2
    head = np.clip(1.25 - head, 0, 1)
    # 몸: 턱 아래부터, 얼굴 너비의 1.3배에서 시작해 아래로 갈수록 넓어짐
    chin = cy + bh * 0.55
    half = bw * 0.7 + np.clip(yy - chin, 0, None) * 0.4    # 목 0.7배 → 한 얼굴 아래서 어깨 1.1배
    body = np.clip((half - np.abs(xx - cx)) / (bw * 0.25), 0, 1) * np.clip((yy - chin) / (bh * 0.2) + 1, 0, 1)
    prior = np.maximum(head, body)
    return mask * cv2.GaussianBlur(prior.astype(np.float32), (0, 0), 3)


def draw_detection(img, face):
    v = img.copy()
    x, y, w, h = face[:4].astype(int)
    t = max(2, img.shape[1] // 300)
    cv2.rectangle(v, (x, y), (x + w, y + h), (69, 122, 255), t + 1)
    for i in range(5):
        px, py = face[4 + 2 * i: 6 + 2 * i].astype(int)
        cv2.circle(v, (px, py), t * 3, (77, 201, 255), -1)
    return v
