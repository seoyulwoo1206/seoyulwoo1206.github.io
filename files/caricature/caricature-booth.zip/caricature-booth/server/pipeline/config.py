from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
MODELS = ROOT / "models"
DATA = ROOT / "data"

OUT_SIZE = 1024                # 처리·출력 해상도 (엽서 300dpi 인쇄용). 신경망 스타일은 내부에서 512로 돌리고 다시 키운다
MIN_FACE_PX = 90               # 원본 사진에서 얼굴 폭이 이보다 작으면 "더 가까이" 안내
BG_COLOR = (236, 244, 250)     # 처리용 배경색 (BGR, 연한 크림)
CARD_BG = ((222, 232, 245), (196, 210, 232))   # 최종 카드 배경 그라데이션 (가운데 → 가장자리, BGR)
STICKER_BORDER = 0.012          # 사람 주변 흰 스티커 테두리 두께 (이미지 폭 비율)

# 고를 수 있는 그림체: (키, 모델 파일, 화면 이름, 설명)
STYLES = [
    ("ai", None, "AI 캐리커처", "그림 생성 모델이 내 얼굴 윤곽선을 따라 손그림처럼 다시 그려요 · AI 서버 연결 필요 (추천)"),
    ("marker", None, "손그림 캐리커처", "마커펜 채색, 큰 눈, 큰 머리, 하트 · 인터넷 없이 됨"),
    ("romance", None, "감성 웹툰풍", "별이삼샵 느낌 · 가는 펜선, 차분한 색, 부드러운 명암, 자연스러운 눈"),
    ("comedy", None, "개그 웹툰풍", "연애혁명 느낌 · 동글동글, 크고 단순한 까만 눈, 굵은 선, 밝은 평면색"),
    ("daily", None, "일상툰풍", "이직로그 느낌 · 최소한의 선, 점 눈, 차분한 색"),
    ("watercolor", None, "수채화", "물 번짐과 종이 결 · 내 얼굴 그대로"),
    ("paint", "animegan_face_paint_512_v2", "물감 일러스트", "신경망이 다시 그리는 그림 + 캔버스 질감"),
    ("sketch", None, "연필 스케치", "연필선과 옅은 명암 · 손그림 느낌 · 내 얼굴 그대로"),
]

DEFAULT_STRENGTH = 1.5         # 과장 강도 (1.0 = 거의 과장 없음)
MAX_STRENGTH = 2.4
BIGHEAD_SCALE = 1.20           # 머리를 몸보다 얼마나 크게 (강도 1.5 기준, 1.0 = 안 함)
MIN_SHAPES_FOR_BOOTH_MEAN = 6   # 이만큼 모이면 '오늘 부스 평균 얼굴'을 기준으로 사용
