"""
캐리커처 파이프라인: 사진 1장 → 단계별 중간 결과 + 최종 캐리커처

    ① 얼굴 찾기   ② 정제(정렬·배경 제거)   ③ 특징점 68개
    ④ 평균 얼굴과 비교   ⑤ 과장   ⑥ 그림체 적용

각 단계의 결과 이미지와 처리 시간을 저장해서, 화면에서 과정을 그대로 보여줄 수 있다.
"""
import time
from pathlib import Path

import cv2
import numpy as np

from .config import BIGHEAD_SCALE, DATA, MIN_SHAPES_FOR_BOOTH_MEAN
from .exaggerate import GLOBAL_FRAC, GLOBAL_FRAC_BOOTH, MEAN_FACE, align_affine, bighead, bighead_fit, bighead_points, bighead_scale, draw_compare, exaggerate, normalize_shape
from .landmarks import MeshDetector, compare, draw_landmarks, to68
from .preprocess import BackgroundRemover, FaceAligner, FaceNotFound, compose_card, compose_paper, denoise, draw_detection, enhance_lighting, load_image, person_prior
from . import remote
from .retouch import draw_retouch, retouch
from .stylize import Stylizer

STEPS = [
    ("detect", "얼굴 찾기", "얼굴 검출 신경망(YuNet)이 얼굴 위치와 눈·코·입 5점을 찾아요."),
    ("clean", "사진 정제", "눈이 수평이 되게 돌리고, 밝기와 색을 보정하고, 잡음을 줄인 뒤 분할 모델(U²-Net)로 배경을 지워요."),
    ("retouch", "피부 보정", "얼굴 메시로 피부만 골라(연두색) 잡티를 주변 피부로 메꾸고, 큰 명암은 남기고 잔 결만 다듬고, 피부색을 고르게 해요."),
    ("landmarks", "특징점 468개", "얼굴 메시 신경망이 이마·볼까지 얼굴 전체에 점 468개를 찍어요."),
    ("compare", "평균 얼굴과 비교", "평균 얼굴(하늘색)을 내 얼굴 크기·비율에 맞춰 겹치고, 눈·코·입·턱선 모양이 다른 곳을 숫자로 재요."),
    ("exaggerate", "특징 과장", "가장 튀는 특징 2개를 세게 과장해 점을 옮기고, 그에 맞춰 사진을 매끄럽게 늘려요. 머리는 살짝 크게!"),
    ("stylize", "그림체 입히기", "AI 캐리커처: 과장한 사진에서 윤곽선을 뽑아 붙잡고(ControlNet), 얼굴 특징을 읽어(IP-Adapter), 그림 생성 모델이 손그림처럼 다시 그려요. 만화: 468점 위에 눈·코·입·윤곽선을 새로 그려요. 물감: 생성 신경망(AnimeGAN)이 다시 그려요."),
]


class Pipeline:
    def __init__(self):
        self.aligner = FaceAligner()
        self.bg = BackgroundRemover()
        self.lm = MeshDetector()
        self.style = Stylizer()
        self.shapes_path = DATA / "booth_shapes.npy"
        self.shapes = list(np.load(self.shapes_path)) if self.shapes_path.exists() else []

    def warmup(self):
        self.style.warmup()

    def reference(self):
        """기준 얼굴: 처음엔 학습 데이터 평균, 방문자가 충분히 모이면 '오늘 부스 평균'"""
        if len(self.shapes) >= MIN_SHAPES_FOR_BOOTH_MEAN:
            return np.mean(self.shapes, 0).astype(np.float32), "booth"
        return MEAN_FACE, "dataset"

    def run(self, data: bytes, style: str, strength: float, out_dir: Path, on_step=None, remember=True, glasses=False, beauty=1.0, retouch_amount=1.0):
        out_dir.mkdir(parents=True, exist_ok=True)
        timings = {}

        def done(key, img, t0, ext="jpg"):
            timings[key] = round((time.perf_counter() - t0) * 1000)
            path = out_dir / f"{key}.{ext}"
            cv2.imwrite(str(path), img, [cv2.IMWRITE_JPEG_QUALITY, 90] if ext == "jpg" else [])
            if on_step:
                on_step(key, path.name, timings[key])

        img = load_image(data)

        t = time.perf_counter()
        face = self.aligner.detect(img)
        done("detect", draw_detection(img, face), t)

        t = time.perf_counter()
        crop, box, M = self.aligner.align_crop(img, face)
        crop, _ = enhance_lighting(crop, box)                      # 얼굴 밝기 기준으로 노출·색 보정
        crop = denoise(crop, box)                                  # 잡음 정제 / 흐리면 윤곽 복원
        t_lm = time.perf_counter()
        try:
            pts = self.lm.fit(crop, box)                            # 메시는 보정 전 사진에서 (피부 보정에 필요)
        except RuntimeError as e:
            raise FaceNotFound(str(e))
        t_lm = time.perf_counter() - t_lm
        mask = self.bg.mask(crop)
        mask = person_prior(mask, box)                              # 머리+어깨 바깥은 배경으로
        mask = self.bg.keep_main_person(mask, box)                  # 옆 사람은 지운다
        clean = self.bg.apply(crop, mask)
        done("clean", clean, t)

        t = time.perf_counter()
        crop, skin = retouch(crop, pts, retouch_amount, person=mask)             # 피부 보정 (잡티 제거·결 다듬기·톤 정리)
        clean = self.bg.apply(crop, mask)
        done("retouch", draw_retouch(clean, skin) if skin is not None else clean, t)

        done("landmarks", draw_landmarks(clean, pts), time.perf_counter() - t_lm)

        t = time.perf_counter()
        ref, ref_kind = self.reference()
        ref_a = align_affine(ref, pts)  # 평균 얼굴을 내 얼굴 위치·전체 비율에 맞추기 → 모양 차이만 비교
        metrics = compare(to68(pts), to68(ref_a))
        done("compare", draw_compare(clean, pts, ref_a), t)

        t = time.perf_counter()
        gfrac = GLOBAL_FRAC_BOOTH if ref_kind == "booth" else GLOBAL_FRAC   # 부스 평균이 생기면 얼굴형 비율도 과장
        (warped, mask_w), new_pts, _, strong = exaggerate(clean, pts, ref, strength, glasses, extra=(mask.astype(np.float32),), global_frac=gfrac, beauty=beauty)
        mask_w = np.clip(mask_w, 0, 1)
        p68w = to68(new_pts)
        bh = bighead_scale(BIGHEAD_SCALE, strength) * (1.12 if style == "marker" else 1.0)   # 손그림 캐리커처는 머리 더 크게
        bh = bighead_fit(mask_w, p68w, bh)                                     # 화면 밖으로 안 나가게
        warped = bighead(warped, mask_w, p68w, bh)
        mask_w = bighead((mask_w[..., None] * 255).repeat(3, 2).astype(np.uint8), mask_w, p68w, bh)[..., 0] / 255.0
        p468w = bighead_points(new_pts, bh)                        # 그림체 단계의 이목구비 선도 커진 머리에 맞춰야 함
        p68w = to68(p468w)
        done("exaggerate", warped, t)

        t = time.perf_counter()
        fallback = None
        if style == "ai":
            # 원격 GPU 서버가 그린다. 실패하면 물감 일러스트로 자동 전환 (부스가 멈추지 않게)
            try:
                art = remote.caricature(warped, strength, beauty=beauty >= 0.5, glasses=glasses, mask=mask_w)
            except remote.RemoteError as e:
                fallback = str(e); style = "paint"
        if style != "ai":
            art = self.style(warped, style, p68w, p468=p468w, mask=mask_w, glasses=glasses)
            art = compose_paper(art, mask_w) if style == "marker" else compose_card(art, mask_w)   # 종이+하트 / 스티커 카드
        done("stylize", art, t, ext="png")

        if remember:
            self.shapes.append(normalize_shape(pts))
            self.shapes_path.parent.mkdir(parents=True, exist_ok=True)
            np.save(self.shapes_path, np.array(self.shapes))

        return {"metrics": metrics, "timings": timings, "reference": ref_kind, "strong": strong, "fallback": fallback}


__all__ = ["Pipeline", "FaceNotFound", "STEPS"]
