"""
④ 그림체 적용

두 종류의 그림체가 있다.
- 만화(cartoon): 고전 영상처리 — 경계 보존 스무딩 → 밝기 단계화(셀 셰이딩) → 잉크 윤곽선.
  모델이 아니라 '내 사진'을 그대로 만화로 바꾸기 때문에 본인 얼굴이 가장 잘 남고, 웹캠 화질에도 강하다.
- 신경망(AnimeGAN v2, 8.6MB): 얼굴 사진으로 미리 학습된 경량 생성 신경망이 그림으로 다시 그린다.
  스타일마다 학습된 모델이 따로 있고 (책: 전이 학습), 멋대로 그리지 않도록 원본 윤곽을 다시 섞어 준다.
모델은 처음 쓸 때 한 번만 메모리에 올리고 계속 재사용한다 (책: 모델 서빙).
"""
import cv2
import numpy as np
import onnxruntime as ort

from .config import MODELS, STYLES


def _soft_posterize(L, levels=6, hardness=7.0):
    """밝기를 단계로 나누되 단계 경계를 부드럽게 (얼룩 방지)"""
    step = 255.0 / levels
    t = L / step
    i = np.floor(t)
    f = t - i
    f = 1.0 / (1.0 + np.exp(-(f - 0.5) * hardness))
    return np.clip((i + f) * step, 0, 255)


def _eye_state(src, e):
    """눈 상태: "open"(눈동자 그림) / "narrow"(눈꺼풀 두 줄, 눈동자 없음) / "closed"(곡선 하나).
    메시는 감은 눈·웃는 눈에서도 '조금 뜬 모양'을 내놓기 때문에 사진 증거(눈 가운데가 어두운가)를 함께 본다."""
    w = np.linalg.norm(e[3] - e[0])
    hgt = (np.linalg.norm(e[1] - e[5]) + np.linalg.norm(e[2] - e[4])) / 2
    ratio = hgt / w if w > 0 else 0
    dark = 0.0
    if src is not None and w > 4:
        L = cv2.cvtColor(src, cv2.COLOR_BGR2LAB)[..., 0]
        c = e.mean(0)
        inner = c + (e - c) * np.array([0.7, 0.6], np.float32)       # 속눈썹 선을 피해 눈 가운데만
        m = np.zeros(L.shape, np.uint8)
        cv2.fillPoly(m, [inner.astype(np.int32).reshape(-1, 1, 2)], 255)
        if m.any():
            dark = float((L[m > 0] < 45).mean())                      # 눈동자가 있으면 어두운 픽셀이 많다
    if ratio >= 0.29 and dark >= 0.25:
        return "open"
    if ratio < 0.22 or dark < 0.25:
        return "closed"
    return "narrow"


def _draw_features(canvas, p68, color=(28, 24, 20), src=None):
    """468점 메시에서 고른 68점으로 눈·눈썹·입·코를 그린다 (만화 펜선 + 눈동자 + 입술색).
    src: 그림체 입히기 전 사진 (눈 떴는지 판단용)"""
    from .landmarks import BROW_L, BROW_R, EYE_L, EYE_R, MOUTH_IN, MOUTH_OUT, NOSE_BASE
    h = canvas.shape[0]
    th = max(1, int(round(h / 256)))
    out = canvas.astype(np.float32)
    pts = lambda idx: p68[idx].astype(np.int32).reshape(-1, 1, 2)

    # 입술: 사진의 입술색을 조금 진하게 채운다 (흑백 스케치에선 생략)
    lip = np.zeros(canvas.shape[:2], np.uint8)
    cv2.fillPoly(lip, [pts(MOUTH_OUT)], 255)
    if lip.any() and color == (28, 24, 20):
        col = canvas[lip > 0].astype(np.float32).mean(0)
        hsv = cv2.cvtColor(np.uint8([[col]]), cv2.COLOR_BGR2HSV).astype(np.float32)[0, 0]
        hsv[1] = min(255, hsv[1] * 1.12 + 4); hsv[2] = max(0, hsv[2] * 0.95)
        col2 = cv2.cvtColor(np.uint8([[hsv]]), cv2.COLOR_HSV2BGR)[0, 0].astype(np.float32)
        a = cv2.GaussianBlur(lip, (0, 0), th).astype(np.float32) / 255 * 0.2
        out = out * (1 - a[..., None]) + col2 * a[..., None]

    # 펜선: 위 눈꺼풀·눈썹은 굵게, 나머지는 가늘게 (만화 문법)
    mask = np.zeros(canvas.shape[:2], np.uint8)
    state = {tuple(idx): _eye_state(src, p68[idx]) for idx in (EYE_R, EYE_L)}
    for idx, closed, t in [(BROW_R, False, th + 2), (BROW_L, False, th + 2),
                           (MOUTH_OUT, True, max(1, th - 1)), (MOUTH_IN, False, max(1, th - 1)), (NOSE_BASE, False, max(1, th - 1))]:
        cv2.polylines(mask, [pts(idx)], closed, 255, t, cv2.LINE_AA)
    for idx in (EYE_R, EYE_L):
        e = p68[idx]
        if state[tuple(idx)] != "closed":
            cv2.polylines(mask, [pts(idx[:4])], False, 255, th + 1, cv2.LINE_AA)                      # 위 눈꺼풀 굵게
            cv2.polylines(mask, [pts([idx[3], idx[4], idx[5], idx[0]])], False, 255, max(1, th - 1), cv2.LINE_AA)
        else:
            # 감은 눈·웃는 눈: 위아래 눈꺼풀 가운데를 지나는 곡선 하나 (만화의 '^^' 눈)
            mid = np.array([e[0], (e[1] + e[5]) / 2, (e[2] + e[4]) / 2, e[3]], np.float32)
            t_ = np.linspace(0, 1, 12)[:, None]
            # 4점을 부드러운 곡선으로 (카트멀-롬 대신 간단히 2차 보간)
            curve = np.array([np.interp(t_.ravel(), [0, 1 / 3, 2 / 3, 1], mid[:, i]) for i in range(2)]).T
            curve = cv2.GaussianBlur(curve.astype(np.float32).reshape(-1, 1, 2), (0, 0), 1.0).reshape(-1, 2)
            curve[0], curve[-1] = mid[0], mid[3]
            cv2.polylines(mask, [curve.astype(np.int32).reshape(-1, 1, 2)], False, 255, th + 1, cv2.LINE_AA)
    # 눈동자: 눈이 정말 떠 있을 때만, 하이라이트 점 포함
    iris = np.zeros_like(mask); hl = np.zeros_like(mask)
    for idx in (EYE_R, EYE_L):
        e = p68[idx]
        hgt = (np.linalg.norm(e[1] - e[5]) + np.linalg.norm(e[2] - e[4])) / 2
        if state[tuple(idx)] == "open":
            c = e.mean(0); r = max(2, int(hgt * 0.5))
            cv2.circle(iris, (int(c[0]), int(c[1])), r, 255, -1, cv2.LINE_AA)
            cv2.circle(hl, (int(c[0] - r * 0.35), int(c[1] - r * 0.35)), max(1, int(r * 0.36)), 255, -1, cv2.LINE_AA)
            cv2.circle(hl, (int(c[0] + r * 0.4), int(c[1] + r * 0.4)), max(1, int(r * 0.18)), 255, -1, cv2.LINE_AA)
    eye_clip = np.zeros_like(mask)
    cv2.fillPoly(eye_clip, [pts(EYE_R), pts(EYE_L)], 255)
    iris = cv2.bitwise_and(iris, eye_clip); hl = cv2.bitwise_and(hl, eye_clip)
    m = cv2.GaussianBlur(mask, (0, 0), 0.7).astype(np.float32) / 255 * 0.85
    mi = iris.astype(np.float32) / 255 * 0.8
    mh = hl.astype(np.float32) / 255
    ink = np.array(color, np.float32)
    out = out * (1 - mi[..., None]) + np.array((40, 30, 25), np.float32) * mi[..., None]
    out = out * (1 - mh[..., None]) + 255.0 * mh[..., None]
    out = out * (1 - m[..., None]) + ink * m[..., None]
    return np.clip(out, 0, 255).astype(np.uint8)


def xdog_lines(gray, scale=1.0, sigma=1.1, k=1.6, tau=0.985, phi=12.0):
    """XDoG: 두 가우시안의 차이로 깔끔한 펜선을 뽑는다 (1 = 종이, 0 = 잉크)"""
    g = gray.astype(np.float32) / 255.0
    s1 = sigma * scale
    g1 = cv2.GaussianBlur(g, (0, 0), s1)
    g2 = cv2.GaussianBlur(g, (0, 0), s1 * k)
    d = g1 - tau * g2
    e = np.where(d >= 0.0, 1.0, 1.0 + np.tanh(phi * d * 20))
    return np.clip(e, 0, 1).astype(np.float32)


def _skin(img, p468):
    """그림체용 피부 마스크 (0~1). 메시가 없으면 None"""
    if p468 is None:
        return None
    from .retouch import skin_mask
    return skin_mask(img, p468)


def _blush(out, p468, skin, strength=0.22):
    """볼터치: 광대 위에 분홍 타원을 살짝 (한국식 캐리커처의 시그니처)"""
    if p468 is None or skin is None:
        return out
    h, w = out.shape[:2]
    face_w = float(np.linalg.norm(p468[454] - p468[234]))
    m = np.zeros((h, w), np.float32)
    for i in (50, 280):                                   # 양쪽 볼 중심
        c = p468[i]
        cv2.ellipse(m, (int(c[0]), int(c[1])), (int(face_w * 0.11), int(face_w * 0.07)), 0, 0, 360, 1.0, -1, cv2.LINE_AA)
    m = cv2.GaussianBlur(m, (0, 0), face_w * 0.05) * skin * strength
    pink = np.array((150, 120, 255), np.float32)
    return out * (1 - m[..., None]) + pink * m[..., None]


def _contour(out, mask, color=(40, 30, 28), th=2, alpha=0.85):
    """사람 실루엣(머리·어깨) 바깥 윤곽선 — 그림처럼 보이게"""
    if mask is None:
        return out
    hard = (np.clip(mask, 0, 1) > 0.5).astype(np.uint8)
    cs, _ = cv2.findContours(hard, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    line = np.zeros(hard.shape, np.uint8)
    cv2.drawContours(line, cs, -1, 255, th, cv2.LINE_AA)
    line = cv2.erode(line, np.ones((th, th), np.uint8)) if th > 1 else line
    a = cv2.GaussianBlur(line, (0, 0), 0.6).astype(np.float32) / 255 * alpha * hard   # 실루엣 안쪽에만
    return out * (1 - a[..., None]) + np.array(color, np.float32) * a[..., None]


def cartoon(img, p68=None, levels=7, p468=None, mask=None):
    """카툰: 경계 보존 스무딩 → 부드러운 셀 셰이딩 → XDoG 펜선 → 메시 좌표로 이목구비.
    피부는 더 평평하게(3~4단계) + 볼터치, 실루엣 윤곽선."""
    h = img.shape[0]
    sc = h / 512.0
    skin = _skin(img, p468)
    sm = cv2.edgePreservingFilter(img, flags=cv2.RECURS_FILTER, sigma_s=30 * sc, sigma_r=0.25)
    sm = cv2.bilateralFilter(sm, int(7 * sc) | 1, 40, 5 * sc)
    lab = cv2.cvtColor(sm, cv2.COLOR_BGR2LAB).astype(np.float32)
    L = lab[..., 0]
    Lq = _soft_posterize(L, levels)
    Lmix = np.clip(0.7 * Lq + 0.3 * L, 0, 255)
    if skin is not None:
        # 피부: 크게 흐린 밝기를 3단계로 → 얼룩 없는 평평한 셀 셰이딩 (코·광대 입체감만 남음)
        Ls = cv2.GaussianBlur(L, (0, 0), 6 * sc)
        Lsq = _soft_posterize(Ls, 4, hardness=4.0)
        Lflat = np.clip(0.55 * Lsq + 0.45 * Ls, 0, 255)
        Lmix = Lmix * (1 - skin) + Lflat * skin
    lab[..., 0] = Lmix
    wgt = np.clip((L[..., None] - 40.0) / 60.0, 0, 1)
    lab[..., 1:] = np.clip((lab[..., 1:] - 128) * (1 + 0.35 * wgt) + 128, 0, 255)
    q = cv2.cvtColor(lab.astype(np.uint8), cv2.COLOR_LAB2BGR)
    # 머리카락처럼 어두운 곳은 더 세게 뭉개서 선이 지저분하게 많이 생기지 않게
    g = cv2.cvtColor(sm, cv2.COLOR_BGR2GRAY)
    g2 = cv2.cvtColor(cv2.edgePreservingFilter(sm, flags=cv2.RECURS_FILTER, sigma_s=70 * sc, sigma_r=0.4), cv2.COLOR_BGR2GRAY)
    dk = np.clip((95.0 - g.astype(np.float32)) / 35.0, 0, 1)
    dk = cv2.GaussianBlur(dk, (0, 0), 3 * sc)
    g = (g * (1 - dk) + g2 * dk).astype(np.uint8)
    lines = xdog_lines(g, scale=sc, sigma=1.35)
    # 아주 작은 점박이 제거
    inkmask = (lines < 0.5).astype(np.uint8)
    n, lbl, stats, _ = cv2.connectedComponentsWithStats(inkmask, connectivity=8)
    big = np.zeros(n, bool)
    big[1:] = stats[1:, cv2.CC_STAT_AREA] >= 25 * sc * sc
    lines = np.where(big[lbl], lines, 1.0).astype(np.float32)
    lines = cv2.GaussianBlur(lines, (0, 0), 0.6 * sc)
    if skin is not None:
        lines = 1 - (1 - lines) * (1 - 0.6 * skin)        # 피부 안쪽 잔선은 연하게 (이목구비는 메시 선으로)
    out = q.astype(np.float32) * (0.15 + 0.85 * lines)[..., None]
    out = _blush(out, p468, skin)
    out = _contour(out, mask, th=max(2, int(round(h / 400))))
    out = np.clip(out, 0, 255).astype(np.uint8)
    if p68 is not None:
        out = _draw_features(out, p68, src=img)
    return out


def _paper(h, w, seed=3, fine=0.05, coarse=0.04):
    """종이·캔버스 결 (곱하기용 1 근처 텍스처)"""
    rng = np.random.default_rng(seed)
    n1 = cv2.GaussianBlur(rng.random((h, w), dtype=np.float32), (0, 0), 1.1)
    n2 = cv2.GaussianBlur(rng.random((h, w), dtype=np.float32), (0, 0), 6.0)
    return 1.0 + fine * (n1 - 0.5) * 3.0 + coarse * (n2 - 0.5) * 3.0


def watercolor(img, p68=None, mask=None):
    """수채화: 색을 물감처럼 뭉개고(평균 이동), 밝고 투명하게, 경계는 물이 마른 자국처럼 진하게,
    종이 결과 과립을 얹고, 연필 밑그림을 옅게 남긴다. 모델 없이 사진 그대로 → 본인 얼굴 유지."""
    h, w = img.shape[:2]
    sc = h / 512.0
    # 1) 물감 번짐: 절반 크기에서 평균 이동 필터 (색을 덩어리로)
    small = cv2.resize(img, (w // 2, h // 2), interpolation=cv2.INTER_AREA)
    ms = cv2.pyrMeanShiftFiltering(small, 8, 20)
    ms = cv2.resize(ms, (w, h), interpolation=cv2.INTER_LINEAR)
    ms = cv2.edgePreservingFilter(ms, flags=cv2.RECURS_FILTER, sigma_s=18 * sc, sigma_r=0.2)
    lab = cv2.cvtColor(ms, cv2.COLOR_BGR2LAB).astype(np.float32)
    L, a, b = lab[..., 0], lab[..., 1], lab[..., 2]
    # 2) 수채 특성: 밝고 투명하게, 채도는 살짝 낮게, 색은 밝기보다 조금 더 번지게
    L = 255 - (255 - L) * 0.86
    a = cv2.GaussianBlur(a, (0, 0), 2.5 * sc); b = cv2.GaussianBlur(b, (0, 0), 2.5 * sc)
    a = (a - 128) * 1.05 + 128; b = (b - 128) * 1.05 + 128 + 3
    # 3) 마른 자국: 색 덩어리 경계를 조금 진하게 (물감이 가장자리에 모이는 현상)
    gx = cv2.Sobel(cv2.GaussianBlur(L, (0, 0), 1.5 * sc), cv2.CV_32F, 1, 0, ksize=3)
    gy = cv2.Sobel(cv2.GaussianBlur(L, (0, 0), 1.5 * sc), cv2.CV_32F, 0, 1, ksize=3)
    edge = np.clip(np.sqrt(gx * gx + gy * gy) / 60.0, 0, 1)
    edge = cv2.GaussianBlur(edge, (0, 0), 1.2 * sc)
    L = L * (1 - 0.22 * edge)
    # 4) 과립: 어두운 곳에 고운 알갱이
    rng = np.random.default_rng(11)
    grain = cv2.GaussianBlur(rng.random((h, w), dtype=np.float32), (0, 0), 0.8) - 0.5
    L = L + grain * 26 * np.clip((200 - L) / 150, 0, 1)
    lab[..., 0], lab[..., 1], lab[..., 2] = np.clip(L, 0, 255), np.clip(a, 0, 255), np.clip(b, 0, 255)
    out = cv2.cvtColor(lab.astype(np.uint8), cv2.COLOR_LAB2BGR).astype(np.float32)
    # 5) 종이 결
    out = out * _paper(h, w, seed=5, fine=0.045, coarse=0.035)[..., None]
    # 6) 연필 밑그림: 옅은 회갈색 선
    g = cv2.cvtColor(cv2.edgePreservingFilter(img, flags=cv2.RECURS_FILTER, sigma_s=25 * sc, sigma_r=0.2), cv2.COLOR_BGR2GRAY)
    lines = xdog_lines(g, scale=sc, sigma=1.2, tau=0.985, phi=8.0)
    inkmask = (lines < 0.5).astype(np.uint8)
    n, lbl, stats, _ = cv2.connectedComponentsWithStats(inkmask, connectivity=8)
    big = np.zeros(n, bool); big[1:] = stats[1:, cv2.CC_STAT_AREA] >= 20 * sc * sc
    lines = np.where(big[lbl], lines, 1.0).astype(np.float32)
    lines = cv2.GaussianBlur(lines, (0, 0), 0.8 * sc)
    pencil = np.array((70, 60, 62), np.float32)
    al = (1 - lines) * 0.45
    out = out * (1 - al[..., None]) + pencil * al[..., None]
    out = np.clip(out, 0, 255).astype(np.uint8)
    if p68 is not None:
        feat = _draw_features(out, p68, color=(96, 78, 70), src=img)
        out = cv2.addWeighted(out, 0.45, feat, 0.55, 0)      # 이목구비 선은 옅게
    return out


def oil_texture(img, strength=0.5, size=7):
    """물감 붓 자국 + 캔버스 결 (물감 일러스트 마무리용)"""
    h, w = img.shape[:2]
    try:
        oil = cv2.xphoto.oilPainting(img, size, 1)
    except Exception:
        oil = img
    out = img.astype(np.float32) * (1 - strength) + oil.astype(np.float32) * strength
    out = out * _paper(h, w, seed=9, fine=0.035, coarse=0.03)[..., None]
    return np.clip(out, 0, 255).astype(np.uint8)


def sketch(img, p68=None):
    """연필 스케치: XDoG 펜선 + 옅은 명암(4단계) + 종이색. 모델 없이 사진 그대로."""
    h = img.shape[0]
    sc = h / 512.0
    sm = cv2.edgePreservingFilter(img, flags=cv2.RECURS_FILTER, sigma_s=25 * sc, sigma_r=0.2)
    g = cv2.cvtColor(sm, cv2.COLOR_BGR2GRAY)
    lines = xdog_lines(g, scale=sc, sigma=1.0, tau=0.98, phi=10.0)
    inkmask = (lines < 0.5).astype(np.uint8)
    n, lbl, stats, _ = cv2.connectedComponentsWithStats(inkmask, connectivity=8)
    big = np.zeros(n, bool)
    big[1:] = stats[1:, cv2.CC_STAT_AREA] >= 10 * sc * sc
    lines = np.where(big[lbl], lines, 1.0).astype(np.float32)
    lines = cv2.GaussianBlur(lines, (0, 0), 0.7 * sc)
    # 명암: 밝기를 4단계로 나눠 옅게 (연필로 살살 칠한 느낌), 어두운 곳은 연필 결 추가
    L = g.astype(np.float32)
    Lq = _soft_posterize(L, 4, hardness=5.0)
    shade = 0.55 + 0.45 * (Lq / 255.0)
    yy, xx = np.mgrid[0:h, 0:img.shape[1]].astype(np.float32)
    hatch = 0.5 + 0.5 * np.sin((xx + yy) * (np.pi / (4.0 * sc)))      # 45도 빗금
    dark = np.clip((85.0 - Lq) / 85.0, 0, 1)                          # 머리카락·옷처럼 정말 어두운 곳에만
    shade = shade * (1 - 0.14 * dark * hatch)
    paper = np.array((226, 236, 244), np.float32)                      # 종이색 (BGR, 따뜻한 미색)
    pencil = np.array((52, 48, 50), np.float32)
    tone = paper * shade[..., None]
    out = tone * lines[..., None] + pencil * (1 - lines[..., None])
    out = np.clip(out, 0, 255).astype(np.uint8)
    if p68 is not None:
        out = _draw_features(out, p68, color=(48, 44, 46), src=img)
    return out


def pop(img, p68=None, p468=None, mask=None):
    """팝아트: 만화 필터에 굵은 선 + 4단계 색 + 강한 채도 (앤디 워홀 느낌)"""
    out = cartoon(img, None, levels=4, p468=p468, mask=mask)
    hsv = cv2.cvtColor(out, cv2.COLOR_BGR2HSV).astype(np.float32)
    hsv[..., 1] = np.clip(hsv[..., 1] * 1.6 + 20, 0, 255)
    out = cv2.cvtColor(hsv.astype(np.uint8), cv2.COLOR_HSV2BGR)
    if p68 is not None:
        out = _draw_features(out, p68, src=img)
    return out


def blend_detail(styl, img, amount=0.5):
    sig = max(1.5, img.shape[0] / 170)
    """신경망 결과에 원본의 밝기 윤곽(고주파)을 다시 섞어 본인 얼굴을 지킨다"""
    lab = cv2.cvtColor(styl, cv2.COLOR_BGR2LAB)
    L_p = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)[..., 0].astype(np.float32)
    hp = L_p - cv2.GaussianBlur(L_p, (0, 0), sig)
    lab[..., 0] = np.clip(lab[..., 0].astype(np.float32) + amount * hp, 0, 255).astype(np.uint8)
    return cv2.cvtColor(lab, cv2.COLOR_LAB2BGR)


class Stylizer:
    def __init__(self):
        self.files = {k: f for k, f, *_ in STYLES}
        self.sessions = {}
        opts = ort.SessionOptions()
        opts.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
        self.opts = opts

    def _session(self, style):
        if style not in self.sessions:
            path = MODELS / f"{self.files[style]}.onnx"
            self.sessions[style] = ort.InferenceSession(str(path), self.opts, providers=["CPUExecutionProvider"])
        return self.sessions[style]

    def warmup(self):
        for k, f in self.files.items():
            if f:
                self._session(k)

    def __call__(self, img_bgr, style, p68=None, p468=None, mask=None, glasses=False):
        from .vector import VARIANTS
        if style in VARIANTS and p468 is not None and mask is not None:
            from .retouch import skin_mask
            from .vector import toon
            base = self._paint(img_bgr, p68, style=VARIANTS[style]["base"]) if VARIANTS[style].get("base") else None
            return toon(img_bgr, p468, mask, skin_mask(img_bgr, p468), glasses=glasses, variant=style, base=base)
        if style == "sketch":
            return sketch(img_bgr, p68)
        if style == "watercolor":
            return watercolor(img_bgr, p68, mask)
        if style == "pop":
            return pop(img_bgr, p68, p468=p468, mask=mask)
        if not self.files.get(style):          # 모델 없는 스타일 = 고전 카툰 필터
            return cartoon(img_bgr, p68, p468=p468, mask=mask)
        out = self._paint(img_bgr, p68, style)
        return oil_texture(out, strength=0.45, size=max(5, int(img_bgr.shape[0] / 150)) | 1)

    def _paint(self, img_bgr, p68=None, style="paint"):
        """AnimeGAN 2단계: 전체 512 + 얼굴 크롭 512 (얼굴 해상도 2배) → 원본 윤곽 섞기"""
        h, w = img_bgr.shape[:2]
        sess = self._session(style)

        def run(bgr):
            rgb = cv2.cvtColor(cv2.resize(bgr, (512, 512), interpolation=cv2.INTER_AREA), cv2.COLOR_BGR2RGB)
            x = (rgb.astype(np.float32) / 127.5 - 1.0).transpose(2, 0, 1)[None]
            y = sess.run(None, {"input": x})[0][0]
            o = ((y.transpose(1, 2, 0) + 1.0) * 127.5).clip(0, 255).astype(np.uint8)
            return cv2.cvtColor(o, cv2.COLOR_RGB2BGR)

        out = cv2.resize(run(img_bgr), (w, h), interpolation=cv2.INTER_CUBIC).astype(np.float32)
        if p68 is not None:
            from .landmarks import EYE_L, EYE_R
            iod = float(np.linalg.norm(p68[EYE_L].mean(0) - p68[EYE_R].mean(0)))
            c = p68.mean(0)
            side = int(min(h, w, iod * 5.5))
            x0 = int(np.clip(c[0] - side / 2, 0, w - side)); y0 = int(np.clip(c[1] - side * 0.55, 0, h - side))
            crop = img_bgr[y0:y0 + side, x0:x0 + side]
            face = cv2.resize(run(crop), (side, side), interpolation=cv2.INTER_CUBIC).astype(np.float32)
            fm = np.zeros((h, w), np.float32)
            cv2.ellipse(fm, (int(c[0]), int(c[1])), (int(side * 0.42), int(side * 0.45)), 0, 0, 360, 1.0, -1)
            fm = cv2.GaussianBlur(fm, (0, 0), side * 0.06)[..., None]
            full = out.copy(); full[y0:y0 + side, x0:x0 + side] = face
            out = out * (1 - fm) + full * fm
        out = np.clip(out, 0, 255).astype(np.uint8)
        return blend_detail(out, img_bgr, amount=0.45)
