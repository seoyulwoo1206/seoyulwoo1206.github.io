"""
②-b 피부 보정 (사진 앱의 '뷰티' 기능과 같은 원리, 모델 없이 영상처리)

얼굴 메시 468점으로 피부 영역을 정확히 잡고(눈·눈썹·입은 제외), 그 안에서만
  1. 잡티 제거: 주변보다 갑자기 어둡거나 붉은 '작은 점'을 찾아 주변 피부로 메꾼다 (inpaint)
  2. 결 다듬기: 주파수 분리 — 큰 명암(얼굴 입체감)은 남기고 잔 결(모공·울긋불긋)만 줄인다
  3. 톤 정리: 피부색 얼룩을 고르게, 그늘(다크서클)은 살짝 밝게, 전체를 한 톤 맑게
캐리커처는 특징을 과장하는 그림이지만, 피부는 깨끗해야 '그림'처럼 보인다.
"""
import cv2
import numpy as np

# MediaPipe 468점 윤곽 번호
FACE_OVAL = [10, 338, 297, 332, 284, 251, 389, 356, 454, 323, 361, 288, 397, 365, 379, 378, 400, 377, 152,
             148, 176, 149, 150, 136, 172, 58, 132, 93, 234, 127, 162, 21, 54, 103, 67, 109]
EYE_R_C = [33, 7, 163, 144, 145, 153, 154, 155, 133, 173, 157, 158, 159, 160, 161, 246]
EYE_L_C = [263, 249, 390, 373, 374, 380, 381, 382, 362, 398, 384, 385, 386, 387, 388, 466]
LIPS = [61, 146, 91, 181, 84, 17, 314, 405, 321, 375, 291, 409, 270, 269, 267, 0, 37, 39, 40, 185]
BROW_R_C = [70, 63, 105, 66, 107, 55, 65, 52, 53, 46]
BROW_L_C = [300, 293, 334, 296, 336, 285, 295, 282, 283, 276]

SMOOTH = 0.70       # 잔 결을 얼마나 지울지 (0 = 안 함, 1 = 완전히 매끈)
TONE_EVEN = 0.55    # 피부색 얼룩을 고르게 (0~1)
SHADOW_LIFT = 0.35  # 그늘(다크서클·팔자)을 밝게 (0~1)
BRIGHTEN = 6.0      # 피부 밝기 올리기 (L 단위, 0~100 중)
LESS_RED = 3.0      # 붉은기 빼기 (LAB a 단위)
BLEMISH = True


def _poly(mask, pts, idx, val=255):
    cv2.fillPoly(mask, [pts[idx].astype(np.int32).reshape(-1, 1, 2)], val)


def skin_mask(img, pts):
    """피부 영역(0~1): 얼굴 윤곽 + 목 → 피부색 가중 → 눈·눈썹·입·콧구멍 제외 → 가장자리 부드럽게"""
    h, w = img.shape[:2]
    face_w = np.linalg.norm(pts[454] - pts[234])
    m = np.zeros((h, w), np.uint8)
    _poly(m, pts, FACE_OVAL)
    # 턱 아래 목: 얼굴 윤곽 아래쪽을 아래로 늘린 사다리꼴
    chin = pts[152]; jl, jr = pts[172], pts[397]
    neck = np.array([[jl[0] - 0.05 * face_w, jl[1]], [jr[0] + 0.05 * face_w, jr[1]],
                     [jr[0], chin[1] + 0.9 * face_w], [jl[0], chin[1] + 0.9 * face_w]], np.int32)
    cv2.fillPoly(m, [neck.reshape(-1, 1, 2)], 255)
    m = cv2.dilate(m, np.ones((int(face_w * 0.04) | 1,) * 2, np.uint8))

    # 피부색 가중: 얼굴 중앙(코·볼) 색을 기준으로 거리 → 머리카락·옷·배경은 자연히 빠짐
    lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB).astype(np.float32)
    ref_m = np.zeros((h, w), np.uint8)
    _poly(ref_m, pts, [50, 101, 118, 117, 111, 116, 123, 147, 187, 207, 206, 203, 129, 209, 126, 142])   # 오른볼
    _poly(ref_m, pts, [280, 330, 347, 346, 340, 345, 352, 376, 411, 427, 426, 423, 358, 429, 355, 371])  # 왼볼
    ref_m[m == 0] = 0
    if ref_m.sum() == 0:
        ref_m = m
    mu = lab[ref_m > 0].mean(0)
    sd = lab[ref_m > 0].std(0) + np.array([14, 5, 5], np.float32)
    d2 = (((lab - mu) / (sd * np.array([2.2, 1.6, 1.6], np.float32))) ** 2).sum(-1)
    skin = np.exp(-d2 / 2)
    skin = cv2.GaussianBlur(skin, (0, 0), max(1, face_w * 0.01))
    soft = (m.astype(np.float32) / 255) * np.clip(skin * 1.6, 0, 1)
    # 얼굴 윤곽 안쪽은 피부색과 조금 달라도(그늘) 포함
    inner = np.zeros((h, w), np.uint8); _poly(inner, pts, FACE_OVAL)
    inner = cv2.erode(inner, np.ones((int(face_w * 0.08) | 1,) * 2, np.uint8)).astype(np.float32) / 255
    soft = np.maximum(soft, inner * np.clip(skin * 4, 0.35, 1))

    ex = np.zeros((h, w), np.uint8)
    for idx in (EYE_R_C, EYE_L_C, LIPS, BROW_R_C, BROW_L_C):
        _poly(ex, pts, idx)
    k = int(face_w * 0.035) | 1
    ex = cv2.dilate(ex, np.ones((k, k), np.uint8))
    exf = cv2.GaussianBlur(ex, (0, 0), face_w * 0.012).astype(np.float32) / 255
    soft = soft * (1 - exf)
    return np.clip(cv2.GaussianBlur(soft, (0, 0), max(1, face_w * 0.015)), 0, 1).astype(np.float32)


def remove_blemishes(img, mask, face_w):
    """주변보다 어둡거나 붉은 작은 점(여드름·점·잡티)을 찾아 주변 피부로 메꾼다"""
    lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB).astype(np.float32)
    k = int(face_w * 0.045) | 1
    base = cv2.medianBlur(img, min(k, 31))
    base_lab = cv2.cvtColor(base, cv2.COLOR_BGR2LAB).astype(np.float32)
    dL = base_lab[..., 0] - lab[..., 0]            # 주변보다 어두운 정도
    da = lab[..., 1] - base_lab[..., 1]            # 주변보다 붉은 정도
    spot = ((dL > 9) | (da > 6) | ((dL > 5) & (da > 3))) & (mask > 0.5)
    spot = spot.astype(np.uint8)
    spot = cv2.morphologyEx(spot, cv2.MORPH_OPEN, np.ones((2, 2), np.uint8))
    n, lbl, stats, _ = cv2.connectedComponentsWithStats(spot, connectivity=8)
    max_area = (face_w * 0.06) ** 2
    keep = np.zeros(n, bool)
    for i in range(1, n):
        a, bw, bh = stats[i, cv2.CC_STAT_AREA], stats[i, cv2.CC_STAT_WIDTH], stats[i, cv2.CC_STAT_HEIGHT]
        if a <= max_area and max(bw, bh) < face_w * 0.09:   # 크고 긴 건 주름·그림자 → 놔둠
            keep[i] = True
    spot = keep[lbl].astype(np.uint8) * 255
    if not spot.any():
        return img
    spot = cv2.dilate(spot, np.ones((3, 3), np.uint8))
    r = max(3, int(face_w * 0.012))
    return cv2.inpaint(img, spot, r, cv2.INPAINT_TELEA)


def smooth_skin(img, mask, face_w, amount=SMOOTH):
    """주파수 분리: 큰 명암은 두고 잔 결만 줄인다 (가이드 필터 = 경계 보존 스무딩)"""
    r = max(2, int(face_w * 0.03))
    eps = (0.05 * 255) ** 2
    f = img.astype(np.float32)
    low = cv2.ximgproc.guidedFilter(img, f, r, eps)
    low = cv2.ximgproc.guidedFilter(img, low, r // 2 + 1, eps * 0.5)
    high = f - low
    out = low + high * (1 - amount)
    a = (mask * amount)[..., None]
    return f * (1 - a) + out * a


def even_tone(f, mask, face_w):
    """피부색 얼룩 정리 + 그늘 밝게 + 한 톤 맑게"""
    lab = cv2.cvtColor(np.clip(f, 0, 255).astype(np.uint8), cv2.COLOR_BGR2LAB).astype(np.float32)
    L, a, b = lab[..., 0], lab[..., 1], lab[..., 2]
    sig = face_w * 0.07
    # 색 얼룩: a·b를 넓게 흐린 값 쪽으로 (경계는 피부 마스크 안에서만)
    w = cv2.GaussianBlur(mask, (0, 0), sig) + 1e-3
    a_bl = cv2.GaussianBlur(a * mask, (0, 0), sig) / w
    b_bl = cv2.GaussianBlur(b * mask, (0, 0), sig) / w
    a2 = a + (a_bl - a) * TONE_EVEN * mask
    b2 = b + (b_bl - b) * TONE_EVEN * mask
    # 그늘: 주변보다 어두운 곳만 밝게 (밝은 곳은 그대로 → 입체감 유지)
    L_bl = cv2.GaussianBlur(L * mask, (0, 0), sig * 0.6) / (cv2.GaussianBlur(mask, (0, 0), sig * 0.6) + 1e-3)
    dark = np.clip(L_bl - L, 0, None)
    L2 = L + dark * SHADOW_LIFT * mask
    # 한 톤 맑게 + 붉은기 빼기
    L2 = L2 + BRIGHTEN * 2.55 * mask * np.clip((235 - L2) / 60, 0, 1)
    a2 = a2 - LESS_RED * mask * np.clip((a2 - 128) / 12, 0, 1)
    lab[..., 0], lab[..., 1], lab[..., 2] = np.clip(L2, 0, 255), np.clip(a2, 0, 255), np.clip(b2, 0, 255)
    return cv2.cvtColor(lab.astype(np.uint8), cv2.COLOR_LAB2BGR)


def retouch(img, pts, amount=1.0, person=None):
    """피부 보정 전체. amount 0~1. person: 사람 마스크(0~1) — 배경은 건드리지 않게"""
    if amount <= 0:
        return img, None
    face_w = float(np.linalg.norm(pts[454] - pts[234]))
    mask = skin_mask(img, pts) * amount
    if person is not None:
        mask = mask * np.clip(person, 0, 1).astype(np.float32)
    out = remove_blemishes(img, mask, face_w) if BLEMISH else img
    f = smooth_skin(out, mask, face_w, SMOOTH * amount)
    out = even_tone(f, mask, face_w)
    return out, mask


def draw_retouch(img, mask):
    """피부 영역을 연두색으로 표시 (단계 화면용)"""
    v = img.astype(np.float32)
    tint = np.array((120, 230, 160), np.float32)
    a = (mask * 0.25)[..., None]
    return (v * (1 - a) + tint * a).astype(np.uint8)
