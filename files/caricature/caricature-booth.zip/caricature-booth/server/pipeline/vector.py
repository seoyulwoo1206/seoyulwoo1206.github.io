"""
⑥ 그림체 '만화' — 사진을 필터로 뭉개는 게 아니라, 메시 468점과 분할 마스크로 **처음부터 그린다**.

사진에서 가져오는 건 색(피부·머리·옷·입술)과 머리 모양뿐이고, 나머지는 모두 선과 면으로 새로 그린다:
  머리카락(면 + 하이라이트)  얼굴·목(면 + 그늘 한 단계 + 볼터치)  옷(면)
  눈(흰자·눈동자·하이라이트·속눈썹)  눈썹(면)  코(선)  입(입술 면 + 치아)  윤곽선
과장 단계에서 옮겨진 점을 그대로 쓰기 때문에, 캐리커처의 특징(큰 눈, V턱, 큰 입 …)이 선명하게 보인다.
"""
import cv2
import numpy as np

from .retouch import BROW_L_C, BROW_R_C, EYE_L_C, EYE_R_C, FACE_OVAL, LIPS

INK = (42, 34, 30)                 # 선 색 (BGR, 진한 갈색)
LIPS_IN = [78, 95, 88, 178, 87, 14, 317, 402, 318, 324, 308, 415, 310, 311, 312, 13, 82, 81, 80, 191]
# 눈 윤곽 16점을 '위 눈꺼풀'(안쪽 코너→바깥 코너)과 '아래 눈꺼풀'(같은 방향)로 나눔 — 둘 다 9점
EYE_R_UP = [133, 173, 157, 158, 159, 160, 161, 246, 33]
EYE_R_LO = [133, 155, 154, 153, 145, 144, 163, 7, 33]
EYE_L_UP = [362, 398, 384, 385, 386, 387, 388, 466, 263]
EYE_L_LO = [362, 382, 381, 380, 374, 373, 390, 249, 263]
NOSE_BASE_C = [98, 97, 2, 326, 327]
JAW_C = FACE_OVAL[8:29]            # 454(오른쪽 귀 앞) → 턱 → 234(왼쪽 귀 앞)


# ----------------------------------------------------------------------------- 기하 도우미
def catmull(pts, closed=False, n=8):
    """점 몇 개를 지나는 매끄러운 곡선 (Catmull-Rom) → 점 많이"""
    p = np.asarray(pts, np.float32)
    if closed:
        p = np.vstack([p[-1:], p, p[:2]])
    else:
        p = np.vstack([p[:1], p, p[-1:]])
    out = []
    for i in range(1, len(p) - 2):
        p0, p1, p2, p3 = p[i - 1], p[i], p[i + 1], p[i + 2]
        for t in np.linspace(0, 1, n, endpoint=False):
            t2, t3 = t * t, t * t * t
            out.append(0.5 * ((2 * p1) + (-p0 + p2) * t + (2 * p0 - 5 * p1 + 4 * p2 - p3) * t2 + (-p0 + 3 * p1 - 3 * p2 + p3) * t3))
    if not closed:
        out.append(p[-2])
    return np.array(out, np.float32)


def _i32(pts):
    return np.asarray(pts, np.float32).astype(np.int32).reshape(-1, 1, 2)


def _col(color):
    return tuple(float(c) for c in color)


def fill(canvas, pts, color, closed=True, smooth=True):
    q = catmull(pts, closed=True) if smooth else np.asarray(pts, np.float32)
    cv2.fillPoly(canvas, [_i32(q)], _col(color), cv2.LINE_AA)


ROUGH = 0.0   # 펜선 흔들림 (0 = 매끈, 1 = 손으로 그린 듯) — toon()이 그림체에 맞춰 설정


def stroke(canvas, pts, color, th, closed=False, smooth=True, taper=False):
    q = catmull(pts, closed=closed) if smooth else np.asarray(pts, np.float32)
    if ROUGH > 0 and len(q) > 3:
        rng = np.random.default_rng(int(abs(q[0]).sum()) & 0xFFFF)
        jit = cv2.GaussianBlur(rng.normal(0, 1, (len(q), 2)).astype(np.float32).reshape(-1, 1, 2), (0, 0), 1.5).reshape(-1, 2)
        q = q + jit * ROUGH * th * 0.6
    if taper and len(q) > 4:                          # 끝으로 갈수록 가늘게 (붓 느낌)
        n = len(q)
        for i in range(n - 1):
            w = th * (0.45 + 0.55 * np.sin(np.pi * (i + 0.5) / n))
            cv2.line(canvas, tuple(q[i].astype(int)), tuple(q[i + 1].astype(int)), _col(color), max(1, int(round(w))), cv2.LINE_AA)
    else:
        cv2.polylines(canvas, [_i32(q)], closed, _col(color), max(1, int(round(th))), cv2.LINE_AA)


def clean_mask(m, close_k, open_k, blur):
    """마스크를 그림처럼 매끈한 덩어리로 (구멍 메우고, 부스러기 떼고, 가장자리 둥글게)"""
    m8 = (m > 0.5).astype(np.uint8) * 255
    if close_k > 1:
        m8 = cv2.morphologyEx(m8, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (close_k | 1, close_k | 1)))
    if open_k > 1:
        m8 = cv2.morphologyEx(m8, cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (open_k | 1, open_k | 1)))
    if blur > 0:
        m8 = (cv2.GaussianBlur(m8, (0, 0), blur) > 127).astype(np.uint8) * 255
    return m8


def biggest(m8, keep=1):
    """가장 큰 덩어리 keep개만"""
    n, lbl, stats, _ = cv2.connectedComponentsWithStats(m8, connectivity=8)
    if n <= 1:
        return m8
    order = np.argsort(-stats[1:, cv2.CC_STAT_AREA]) + 1
    out = np.isin(lbl, order[:keep])
    return out.astype(np.uint8) * 255


def paint(canvas, m8, color):
    a = (m8.astype(np.float32) / 255)[..., None]
    return canvas * (1 - a) + np.array(color, np.float32) * a


def outline(canvas, m8, color, th):
    cs, _ = cv2.findContours(m8, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    for c in cs:
        if cv2.contourArea(c) < 50:
            continue
        c = cv2.approxPolyDP(c, 1.5, True)
        if len(c) >= 4:
            stroke(canvas, c.reshape(-1, 2), color, th, closed=True)
    return canvas


def median_color(img, m8, q=50):
    if m8.sum() == 0:
        return np.array((128, 128, 128), np.float32)
    px = img[m8 > 0].astype(np.float32)
    return np.percentile(px, q, axis=0)


def adjust(bgr, light=1.0, sat=1.0):
    hsv = cv2.cvtColor(np.uint8([[np.clip(bgr, 0, 255)]]), cv2.COLOR_BGR2HSV).astype(np.float32)[0, 0]
    hsv[1] = np.clip(hsv[1] * sat, 0, 255); hsv[2] = np.clip(hsv[2] * light, 0, 255)
    return cv2.cvtColor(np.uint8([[hsv]]), cv2.COLOR_HSV2BGR)[0, 0].astype(np.float32)


# ----------------------------------------------------------------------------- 영역 나누기
def regions(img, p468, mask, skin):
    """사람 마스크를 머리카락 / 피부(얼굴·목·귀) / 옷(나머지)으로 나눈다"""
    h, w = img.shape[:2]
    face_w = float(np.linalg.norm(p468[454] - p468[234]))
    person = (np.clip(mask, 0, 1) > 0.5).astype(np.uint8) * 255
    chin_y = float(p468[152, 1])
    brow_y = float(p468[[70, 300], 1].mean())

    oval = np.zeros((h, w), np.uint8)
    cv2.fillPoly(oval, [_i32(catmull(p468[FACE_OVAL], closed=True))], 255)
    yy = np.arange(h)[:, None].repeat(w, 1)
    head_zone = ((yy < chin_y + 0.15 * face_w) * 255).astype(np.uint8)

    # 이목구비 자리(눈·눈썹·입)는 머리카락 후보에서 뺀다 (어두워서 머리카락으로 오인하기 때문)
    feat = np.zeros((h, w), np.uint8)
    for idx in (EYE_R_C, EYE_L_C, BROW_R_C, BROW_L_C, LIPS):
        cv2.fillPoly(feat, [_i32(p468[idx])], 255)
    feat = cv2.dilate(feat, np.ones((int(face_w * 0.06) | 1,) * 2, np.uint8))

    # 머리카락: 사람 ∩ 머리 구역 ∩ 피부색 아님 (앞머리가 이마를 덮으면 얼굴 타원 안이라도 머리카락)
    lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)
    L = lab[..., 0].astype(np.float32)
    skin_L = np.median(L[(skin > 0.6) & (oval > 0)]) if ((skin > 0.6) & (oval > 0)).any() else 150
    not_skin = ((skin < 0.35) | (L < skin_L - 45)).astype(np.uint8) * 255
    # 얼굴 타원 안에서는 눈썹 위(이마)만 머리카락이 될 수 있다 (볼 그늘·콧구멍을 머리카락으로 오인 방지)
    forehead = ((yy < brow_y - 0.04 * face_w) * 255).astype(np.uint8)
    allow = cv2.bitwise_or(cv2.bitwise_not(oval), forehead)
    hair = cv2.bitwise_and(cv2.bitwise_and(cv2.bitwise_and(person, head_zone), not_skin), allow)
    hair = cv2.bitwise_and(hair, cv2.bitwise_not(feat))
    hair = clean_mask(hair, int(face_w * 0.08), int(face_w * 0.05), face_w * 0.015)
    hair = biggest(hair, keep=2)

    # 피부: 색 기반 피부 + 얼굴 타원 안쪽(머리카락 제외) → 눈·입은 나중에 위에 그림
    sk = np.maximum((skin > 0.45).astype(np.uint8) * 255, oval)
    sk = cv2.bitwise_and(sk, person)
    sk = cv2.bitwise_and(sk, cv2.bitwise_not(hair))
    sk = clean_mask(sk, int(face_w * 0.06), int(face_w * 0.03), face_w * 0.012)
    sk = cv2.bitwise_or(sk, cv2.bitwise_and(cv2.bitwise_and(oval, person), cv2.bitwise_not(hair)))
    hair = cv2.bitwise_and(hair, cv2.bitwise_not(sk))
    # 옷: 나머지
    body = cv2.bitwise_and(person, cv2.bitwise_not(cv2.bitwise_or(sk, hair)))
    body = clean_mask(body, int(face_w * 0.06), int(face_w * 0.03), face_w * 0.01)
    body = cv2.bitwise_and(body, cv2.bitwise_not(cv2.bitwise_or(sk, hair)))
    return person, sk, hair, body, oval, face_w


# ----------------------------------------------------------------------------- 눈 상태
def eye_state(img, p468, up, lo):
    """"open" / "closed". 세로/가로 비율 + 눈 가운데가 어두운가(눈동자)로 판단"""
    u, l = p468[up], p468[lo]
    w = np.linalg.norm(u[-1] - u[0])
    hgt = np.abs(l[1:-1, 1] - u[1:-1, 1]).mean()
    ratio = hgt / max(w, 1)
    poly = np.vstack([u, l[::-1]])
    c = poly.mean(0)
    inner = c + (poly - c) * np.array([0.7, 0.6], np.float32)
    m = np.zeros(img.shape[:2], np.uint8)
    cv2.fillPoly(m, [_i32(inner)], 255)
    L = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)[..., 0]
    dark = float((L[m > 0] < 45).mean()) if m.any() else 0.0
    return "open" if (ratio >= 0.29 and dark >= 0.25) or (ratio >= 0.22 and dark >= 0.45) else "closed", ratio


# ----------------------------------------------------------------------------- 그림체 변형
# 유명 웹툰들이 '어떻게 그리는지'를 참고한 모드 (그림체는 저작권 대상이 아니지만, 캐릭터를 베끼진 않는다):
#  romance : 별이삼샵(혀노) 느낌 — 실제 비율에 가까운 얼굴, 가늘고 살짝 거친 펜선, 차분하고 따뜻한 색, 부드러운 명암, 눈은 자연스러운 크기
#  comedy  : 연애혁명(232) 느낌 — 동글동글 단순한 얼굴, 크고 단순한 까만 눈 + 하이라이트 하나, 굵고 깔끔한 선, 밝은 평면색, 통통한 볼
#  daily   : 이직로그 같은 일상툰 느낌 — 최소한의 선, 작은 점 눈, 차분한 색, 명암 거의 없음
VARIANTS = {
    # 손그림 캐리커처(마커펜) — 행사장 캐리커처 작가 그림: 머리 크게, 눈 크고 동그랗게, 작은 턱, 마커로 칠한 듯한 3톤 명암 + 붓결, 살짝 흔들리는 펜선
    "marker": dict(line=1.25, rough=0.7, eye="natural", eye_scale=(1.22, 1.45), iris=0.34, lash=1.7, strands=True, hair_tone=True,
                   shade="marker", blush=0.30, skin_tint=((200, 218, 250), 0.45), sat=1.12, nose="tick", mouth="lips", chin_line=True, brow="fill",
                   ink=(62, 46, 40), grain=0.045, marker=True),
    "romance": dict(line=0.8, rough=0.5, eye="natural", eye_scale=(1.03, 1.1), iris=0.30, lash=1.5, strands=True, hair_tone=True,
                    shade="soft", blush=0.18, skin_tint=((198, 216, 247), 0.42), sat=1.0, nose="side", mouth="soft", chin_line=True, brow="fill",
                    ink=(58, 44, 38), grain=0.05, base="paint"),
    "comedy": dict(line=1.5, rough=0.0, eye="dot", eye_scale=(1.3, 1.6), iris=0.36, lash=1.2, strands=False, hair_tone=False,
                   shade="none", blush=0.22, skin_tint=((214, 228, 252), 0.5), sat=1.15, nose="tiny", mouth="simple", chin_line=False, brow="stroke",
                   ink=(40, 34, 32), grain=0.0),
    "daily": dict(line=1.0, rough=0.15, eye="line", eye_scale=(1.0, 1.0), iris=0.2, lash=1.0, strands=False, hair_tone=False,
                  shade="none", blush=0.10, skin_tint=((210, 222, 240), 0.45), sat=0.8, nose="dot", mouth="simple", chin_line=True, brow="stroke",
                  ink=(70, 62, 58), grain=0.03),
}


def _scale_poly(poly, sx, sy, anchor=None):
    c = poly.mean(0) if anchor is None else anchor
    return c + (poly - c) * np.array([sx, sy], np.float32)


def hair_strands(canvas, img, hair, face_w, color, alpha=0.4):
    """머리카락 결: 사진의 어두운 선(XDoG)을 머리카락 안에서만 가져와 긴 것만 그린다"""
    h = img.shape[0]
    sc = h / 512.0
    g = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY).astype(np.float32) / 255
    g1 = cv2.GaussianBlur(g, (0, 0), 1.0 * sc)
    g2 = cv2.GaussianBlur(g, (0, 0), 1.6 * sc)
    d = g1 - 0.985 * g2
    ink = (d < -0.003).astype(np.uint8) * 255
    inner = cv2.erode(hair, np.ones((int(face_w * 0.03) | 1,) * 2, np.uint8))
    ink = cv2.bitwise_and(ink, inner)
    n, lbl, stats, _ = cv2.connectedComponentsWithStats(ink, connectivity=8)
    keep = np.zeros(n, bool)
    for i in range(1, n):
        if max(stats[i, cv2.CC_STAT_WIDTH], stats[i, cv2.CC_STAT_HEIGHT]) > face_w * 0.2:
            keep[i] = True
    lines = keep[lbl].astype(np.uint8) * 255
    lines = cv2.morphologyEx(lines, cv2.MORPH_CLOSE, np.ones((2, 2), np.uint8))
    a = (cv2.GaussianBlur(lines, (0, 0), 0.7).astype(np.float32) / 255 * alpha)[..., None]
    return canvas * (1 - a) + np.array(color, np.float32) * a


def soft_shade(canvas, L, region, face_w, shade_c, strength=0.6):
    """부드러운 명암: 사진의 큰 밝기 흐름(크게 흐린 L)을 그대로 살려 어두운 쪽을 그늘색으로 (에어브러시 느낌)"""
    reg = region.astype(np.float32) / 255
    Ls = cv2.GaussianBlur(L, (0, 0), face_w * 0.045)
    med = np.median(Ls[region > 0]) if region.any() else 128
    a = np.clip((med - Ls) / 38.0, 0, 1) * reg * strength
    a = cv2.GaussianBlur(a, (0, 0), face_w * 0.01)[..., None]
    return canvas * (1 - a) + np.array(shade_c, np.float32) * a


def marker_shade(canvas, L, region, face_w, base_c, levels=3, dark=0.10, light=0.06):
    """마커펜 명암: 사진의 큰 밝기 흐름을 3톤으로 나누되 경계는 살짝 번지게 + 붓결(비스듬한 줄무늬) + 가장자리 색 고임"""
    h, w = L.shape
    reg = region.astype(np.float32) / 255
    if reg.sum() < 10:
        return canvas
    Ls = cv2.GaussianBlur(L, (0, 0), face_w * 0.05)
    vals = Ls[region > 0]
    lo, med, hi = np.percentile(vals, [20, 50, 85])
    # 어두운 쪽 2단계 (soft step)
    d1 = np.clip((med - Ls) / 14.0, 0, 1); d2 = np.clip((lo - Ls) / 14.0, 0, 1)
    d1 = cv2.GaussianBlur(d1, (0, 0), face_w * 0.008); d2 = cv2.GaussianBlur(d2, (0, 0), face_w * 0.008)
    lt = cv2.GaussianBlur(np.clip((Ls - hi) / 14.0, 0, 1), (0, 0), face_w * 0.008)
    dark_c = adjust(base_c, light=1 - dark, sat=1.25); dark2_c = adjust(base_c, light=1 - 2 * dark, sat=1.35)
    light_c = np.minimum(adjust(base_c, light=1 + light, sat=0.9) + 6, 255)
    out = canvas
    for amt, col in ((d1 * 0.65, dark_c), (d2 * 0.6, dark2_c), (lt * 0.6, light_c)):
        a = (amt * reg)[..., None]
        out = out * (1 - a) + np.array(col, np.float32) * a
    # 붓결: 비스듬한 줄무늬 (노이즈를 한 방향으로 길게 흐림)
    rng = np.random.default_rng(3)
    n = rng.random((h, w), dtype=np.float32)
    n = cv2.GaussianBlur(n, (0, 0), sigmaX=2.0, sigmaY=face_w * 0.05)
    M = cv2.getRotationMatrix2D((w / 2, h / 2), 35, 1.0)
    n = cv2.warpAffine(n, M, (w, h), borderMode=cv2.BORDER_REFLECT)
    n = (n - n.mean()) / (n.std() + 1e-6)
    streak = np.clip(n, -2, 2) * 0.016
    out = out * (1 + (streak * reg)[..., None])
    # 가장자리 색 고임: 영역 경계 안쪽 띠를 살짝 진하게
    er = cv2.erode(region, np.ones((int(face_w * 0.025) | 1,) * 2, np.uint8))
    rim = cv2.GaussianBlur((region.astype(np.float32) - er.astype(np.float32)) / 255, (0, 0), face_w * 0.006) * 0.35
    out = out * (1 - rim[..., None]) + np.array(dark_c, np.float32) * rim[..., None]
    return out


# ----------------------------------------------------------------------------- 개인차 (평균 얼굴 대비)
def _ratios(p):
    """얼굴 너비 기준 비율: 눈 너비, 눈 높이/너비, 입 너비, 입술 두께, 코 너비, 눈썹 두께, 눈 사이 거리"""
    fw = float(np.linalg.norm(p[454] - p[234])) + 1e-6
    ew = (np.linalg.norm(p[33] - p[133]) + np.linalg.norm(p[263] - p[362])) / 2
    eh = (abs(p[159, 1] - p[145, 1]) + abs(p[386, 1] - p[374, 1])) / 2
    mw = np.linalg.norm(p[61] - p[291])
    lip = abs(p[0, 1] - p[13, 1]) + abs(p[17, 1] - p[14, 1])          # 윗입술 두께 + 아랫입술 두께 (입 벌림과 무관)
    nw = np.linalg.norm(p[98] - p[327])
    bt = (abs(p[105, 1] - p[52, 1]) + abs(p[66, 1] - p[65, 1]) + abs(p[334, 1] - p[282, 1]) + abs(p[296, 1] - p[295, 1])) / 4
    gap = np.linalg.norm(p[133] - p[362])
    return np.array([ew / fw, eh / max(ew, 1e-6), mw / fw, lip / fw, nw / fw, bt / fw, gap / fw], np.float32)


REF_RATIOS = None   # 기준 비율: 부스 평균 얼굴(6명 이상 모이면) → 없으면 아래 상수 (한국 10대 7명 중앙값으로 보정)
REF_KR = np.array([1.171, 1.111, 1.054, 1.227, 1.031, 1.214, 1.053], np.float32)   # MediaPipe 표준 얼굴 → 한국 10대 중앙값 보정 (연습 사진 7명)


def person_traits(p468, k=2.0):
    """기준 얼굴 대비 그 사람의 특징을 배율로 (1.0 = 평균). k배로 키워서 그리는 단계에서 차이가 보이게 한다.
    반환: dict(eye_w, eye_h, mouth, lip, nose, brow, gap)"""
    global REF_RATIOS
    if REF_RATIOS is None:
        from .exaggerate import MEAN_FACE
        REF_RATIOS = _ratios(MEAN_FACE) * (REF_KR if REF_KR is not None else 1.0)
    r, m = _ratios(p468), REF_RATIOS
    dev = (r - m) / m
    mul = np.clip(1 + k * dev, 0.6, 1.7)
    keys = ("eye_w", "eye_h", "mouth", "lip", "nose", "brow", "gap")
    return dict(zip(keys, mul.tolist()))


# ----------------------------------------------------------------------------- 메인
def toon(img, p468, mask, skin, glasses=False, variant="romance", base=None):
    """base: 면 대신 깔아 둘 채색 그림 (예: 신경망 채색) — 그 위에 선·눈·입만 그린다 (하이브리드)"""
    global ROUGH
    V = VARIANTS.get(variant, VARIANTS["romance"])
    ROUGH = V["rough"]
    INK_ = V["ink"]
    h, w = img.shape[:2]
    person, sk, hair, body, oval, face_w = regions(img, p468, mask, skin)
    th = max(2.0, h / 340) * V["line"]           # 기본 선 굵기
    lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB).astype(np.float32)
    L = lab[..., 0]
    canvas = np.full((h, w, 3), 255, np.float32)
    fw = face_w

    # ---- 색 뽑기 (사진에서)
    cheek = np.zeros((h, w), np.uint8)
    for idx in ([50, 101, 118, 117, 111, 116, 123, 147, 187, 207, 206, 203, 129, 209, 126, 142],
                [280, 330, 347, 346, 340, 345, 352, 376, 411, 427, 426, 423, 358, 429, 355, 371]):
        cv2.fillPoly(cheek, [_i32(p468[idx])], 255)
    tint, mix = V["skin_tint"]
    mix = mix * 0.5                                        # 복숭아빛은 절반만 — 사람마다 피부 톤 차이가 남게
    skin_c = adjust(median_color(img, cheek, 55), light=1.06, sat=V["sat"] * 1.05)
    skin_c = skin_c * (1 - mix) + np.array(tint, np.float32) * mix
    T = person_traits(p468) if base is None else dict(eye_w=1, eye_h=1, mouth=1, lip=1, nose=1, brow=1, gap=1)
    shade_c = adjust(skin_c, light=0.85, sat=1.25)
    hair_c = adjust(median_color(img, hair, 45), light=0.92, sat=V["sat"]) if hair.any() else np.array((40, 35, 35), np.float32)
    hair_hi = adjust(hair_c, light=1.5, sat=0.9) + 22
    hair_dk = hair_c * 0.5

    if base is not None:
        canvas = cv2.edgePreservingFilter(base, flags=cv2.RECURS_FILTER, sigma_s=12 * (h / 512), sigma_r=0.12).astype(np.float32)

    # ---- 옷: 크게 흐린 색을 3단계로
    if base is None and body.any():
        sm = cv2.GaussianBlur(img, (0, 0), fw * 0.035)
        lab_b = cv2.cvtColor(sm, cv2.COLOR_BGR2LAB).astype(np.float32)
        Lb = lab_b[..., 0]
        lv = np.percentile(Lb[body > 0], [30, 70])
        Lq = np.where(Lb < lv[0], lv[0] - 12, np.where(Lb < lv[1], (lv[0] + lv[1]) / 2, lv[1] + 12))
        lab_b[..., 0] = np.clip(Lq, 0, 255)
        lab_b[..., 1:] = (lab_b[..., 1:] - 128) * V["sat"] + 128
        flat = cv2.cvtColor(np.clip(lab_b, 0, 255).astype(np.uint8), cv2.COLOR_LAB2BGR).astype(np.float32)
        a = (body.astype(np.float32) / 255)[..., None]
        canvas = canvas * (1 - a) + flat * a
        if V.get("marker"):
            canvas = marker_shade(canvas, L, body, fw, median_color(flat.astype(np.uint8), body, 50), dark=0.12, light=0.08)

    # ---- 피부 면 + 명암 + 볼터치
    if base is None:
        canvas = paint(canvas, sk, skin_c)
    neck = np.zeros((h, w), np.uint8)
    jaw = catmull(p468[JAW_C])
    first_left = jaw[0, 0] < jaw[-1, 0]
    bottom = np.array([[w - 1, h - 1], [0, h - 1]], np.float32) if first_left else np.array([[0, h - 1], [w - 1, h - 1]], np.float32)
    cv2.fillPoly(neck, [_i32(np.vstack([jaw, bottom]))], 255)
    neck = cv2.bitwise_and(neck, sk)
    neck = cv2.erode(neck, np.ones((int(fw * 0.02) | 1,) * 2, np.uint8))
    if base is not None:
        pass                                               # 채색 그림에 이미 명암이 있음
    elif V["shade"] == "marker":
        canvas = marker_shade(canvas, L, sk, fw, skin_c)
        a = (cv2.GaussianBlur(neck, (0, 0), fw * 0.012).astype(np.float32) / 255 * 0.5)[..., None]
        canvas = canvas * (1 - a) + np.array(shade_c, np.float32) * a
    elif V["shade"] == "soft":
        canvas = soft_shade(canvas, L, sk, fw, shade_c, 0.5)
        a = (cv2.GaussianBlur(neck, (0, 0), fw * 0.015).astype(np.float32) / 255 * 0.6)[..., None]
        canvas = canvas * (1 - a) + np.array(shade_c, np.float32) * a
    elif V["shade"] == "cel":
        canvas = paint(canvas, neck, shade_c)
        M = np.float32([[1, 0, 0], [0, 1, fw * 0.045]])
        under = cv2.warpAffine(hair, M, (w, h))
        under = cv2.bitwise_and(cv2.bitwise_and(under, sk), cv2.bitwise_not(hair))
        under = clean_mask(under, int(fw * 0.02), int(fw * 0.02), fw * 0.008)
        canvas = paint(canvas, under, shade_c)
    else:
        a = (cv2.GaussianBlur(neck, (0, 0), fw * 0.01).astype(np.float32) / 255 * 0.35)[..., None]
        canvas = canvas * (1 - a) + np.array(shade_c, np.float32) * a
    if V["blush"] > 0:
        m = np.zeros((h, w), np.float32)
        for i in (50, 280):
            c = p468[i]
            cv2.ellipse(m, (int(c[0]), int(c[1])), (int(fw * 0.11), int(fw * 0.065)), 0, 0, 360, 1.0, -1, cv2.LINE_AA)
        m = cv2.GaussianBlur(m, (0, 0), fw * 0.045) * (sk.astype(np.float32) / 255) * V["blush"]
        canvas = canvas * (1 - m[..., None]) + np.array((150, 120, 255), np.float32) * m[..., None]

    # ---- 머리카락 면 + 톤 + 하이라이트 + 결
    if hair.any() and base is not None:
        if V["strands"]:
            canvas = hair_strands(canvas, img, hair, fw, hair_dk, alpha=0.3)
    elif hair.any() and V.get("marker"):
        canvas = paint(canvas, hair, hair_c)
        canvas = marker_shade(canvas, L, hair, fw, hair_c, dark=0.16, light=0.22)
        if V["strands"]:
            canvas = hair_strands(canvas, img, hair, fw, hair_dk, alpha=0.5)
    elif hair.any():
        canvas = paint(canvas, hair, hair_c)
        if V["hair_tone"]:
            # 사진의 큰 밝기 흐름을 3톤으로 (어두운 안쪽 / 기본 / 밝은 윗면), 경계는 부드럽게
            Lh = cv2.GaussianBlur(L, (0, 0), fw * 0.05)
            lo, hi_ = np.percentile(Lh[hair > 0], [25, 75])
            dark = np.clip((lo - Lh) / 25.0, 0, 1) * (hair.astype(np.float32) / 255)
            light = np.clip((Lh - hi_) / 25.0, 0, 1) * (hair.astype(np.float32) / 255)
            dark = cv2.GaussianBlur(dark, (0, 0), fw * 0.012)[..., None] * 0.7
            light = cv2.GaussianBlur(light, (0, 0), fw * 0.012)[..., None] * 0.55
            canvas = canvas * (1 - dark) + hair_dk * dark
            canvas = canvas * (1 - light) + hair_hi * light
        else:
            Lh = cv2.GaussianBlur(L, (0, 0), fw * 0.08)
            hi = ((Lh > np.percentile(Lh[hair > 0], 78)) * 255).astype(np.uint8)
            hi = cv2.bitwise_and(hi, cv2.erode(hair, np.ones((int(fw * 0.05) | 1,) * 2, np.uint8)))
            hi = clean_mask(hi, int(fw * 0.04), int(fw * 0.08), fw * 0.03)
            hi = biggest(hi, keep=2)
            a = (hi.astype(np.float32) / 255 * 0.45)[..., None]
            canvas = canvas * (1 - a) + hair_hi * a
        if V["strands"]:
            canvas = hair_strands(canvas, img, hair, fw, hair_dk)

    # ---- 윤곽선: 실루엣, 머리카락, 턱선, 옷 경계
    outline(canvas, person, INK_, th * 1.1)
    if base is None:                                       # 채색 그림 위에는 영역 경계선을 긋지 않는다 (어긋나 보임)
        if hair.any():
            outline(canvas, hair, INK_, th * 0.9)
        if body.any():
            outline(canvas, body, INK_, th * 0.7)
    if V["chin_line"] and base is None:
        stroke(canvas, p468[JAW_C], INK_, th * 0.9, taper=True)

    # ---- 눈썹
    brow_c = adjust(hair_c, light=0.85)
    for idx in (BROW_R_C, BROW_L_C):
        if base is not None:                               # 채색 그림의 눈썹 위에 결만 살짝 보강
            tmp = canvas.copy(); fill(tmp, p468[idx], brow_c)
            bm = np.zeros((h, w), np.uint8); cv2.fillPoly(bm, [_i32(catmull(p468[idx], closed=True))], 255)
            a = (cv2.GaussianBlur(bm, (0, 0), fw * 0.006).astype(np.float32) / 255 * 0.45)[..., None]
            canvas = canvas * (1 - a) + tmp * a
        elif V["brow"] == "fill":
            fill(canvas, p468[idx], brow_c)
        else:
            mid = (p468[idx[:5]] + p468[idx[5:][::-1]]) / 2
            stroke(canvas, mid, brow_c, th * 1.5 * T["brow"], taper=True)

    # ---- 눈
    states = [eye_state(img, p468, up, lo) for up, lo in ((EYE_R_UP, EYE_R_LO), (EYE_L_UP, EYE_L_LO))]
    any_open = any(s == "open" for s, _ in states)
    sx, sy = V["eye_scale"]
    sx, sy = sx * (0.75 + 0.25 * T["eye_w"]) * (T["eye_w"] ** 0.5), sy * (T["eye_h"] ** 0.7)   # 큰 눈은 더 크게, 가는 눈은 더 가늘게
    for (up, lo), (st, ratio) in zip(((EYE_R_UP, EYE_R_LO), (EYE_L_UP, EYE_L_LO)), states):
        u0, l0 = p468[up], p468[lo]
        ew = float(np.linalg.norm(u0[-1] - u0[0]))
        is_open = st == "open" or (any_open and ratio >= 0.2)
        if not is_open:
            mid = (u0 + l0) / 2
            mid[1:-1, 1] -= ew * 0.02
            stroke(canvas, mid, INK_, th * 1.5, taper=True)         # 감은 눈 '^^'
            continue
        c0 = np.vstack([u0, l0]).mean(0)
        u, l = _scale_poly(u0, sx, sy, c0), _scale_poly(l0, sx, sy, c0)
        poly = np.vstack([u, l[::-1]])
        c = poly.mean(0)
        if V["eye"] == "line":
            # 일상툰: 눈은 위 눈꺼풀 선 + 작은 까만 점
            stroke(canvas, u, INK_, th * 1.1, taper=True)
            cv2.circle(canvas, (int(c[0]), int(c[1] + ew * 0.05)), max(2, int(ew * 0.13)), _col(INK_), -1, cv2.LINE_AA)
            cv2.circle(canvas, (int(c[0] - ew * 0.05), int(c[1] - ew * 0.0)), max(1, int(ew * 0.04)), (255, 255, 255), -1, cv2.LINE_AA)
            continue
        eye_m = np.zeros((h, w), np.uint8)
        cv2.fillPoly(eye_m, [_i32(catmull(poly, closed=True))], 255)
        r = max(3, int(ew * V["iris"] * min(1.0, 0.55 + 0.45 * T["eye_h"])))   # 가는 눈은 눈동자도 작게
        cy = c[1] + ew * 0.03
        iris = np.zeros((h, w), np.uint8); pup = np.zeros((h, w), np.uint8); hl = np.zeros((h, w), np.uint8)
        cv2.circle(iris, (int(c[0]), int(cy)), r, 255, -1, cv2.LINE_AA)
        if V["eye"] == "dot":
            # 개그툰: 흰자 없이 큰 까만 눈 + 큰 하이라이트 하나
            canvas = paint(canvas, eye_m, (252, 252, 254))
            cv2.ellipse(iris, (int(c[0]), int(cy)), (int(r * 0.85), int(r * 1.05)), 0, 0, 360, 255, -1, cv2.LINE_AA)
            iris = cv2.bitwise_and(iris, eye_m)
            canvas = paint(canvas, iris, (22, 18, 18))
            cv2.circle(hl, (int(c[0] - r * 0.3), int(cy - r * 0.35)), max(2, int(r * 0.32)), 255, -1, cv2.LINE_AA)
            canvas = paint(canvas, cv2.bitwise_and(hl, iris), (255, 255, 255))
            stroke(canvas, u, INK_, th * V["lash"], taper=True)
            stroke(canvas, poly, INK_, th * 0.7, closed=True)
            continue
        # natural (romance): 흰자 + 갈색 눈동자(위 어둡게) + 동공 + 하이라이트 작게
        if base is not None:
            a = (eye_m.astype(np.float32) / 255 * 0.55)[..., None]
            canvas = canvas * (1 - a) + np.array((248, 247, 249), np.float32) * a
        else:
            canvas = paint(canvas, eye_m, (248, 247, 249))
        cv2.circle(pup, (int(c[0]), int(cy)), int(r * 0.45), 255, -1, cv2.LINE_AA)
        cv2.circle(hl, (int(c[0] - r * 0.4), int(cy - r * 0.4)), max(2, int(r * 0.26)), 255, -1, cv2.LINE_AA)
        cv2.circle(hl, (int(c[0] + r * 0.45), int(cy + r * 0.4)), max(1, int(r * 0.12)), 255, -1, cv2.LINE_AA)
        iris, pup, hl = (cv2.bitwise_and(x, eye_m) for x in (iris, pup, hl))
        yy = (np.arange(h, dtype=np.float32)[:, None] - (cy - r)) / max(2 * r, 1)
        t = np.clip(yy, 0, 1)[..., None]
        col = np.array((30, 24, 24), np.float32) * (1 - t) + np.array((60, 70, 120), np.float32) * t
        a = (iris.astype(np.float32) / 255)[..., None]
        canvas = canvas * (1 - a) + col * a
        canvas = paint(canvas, pup, (14, 12, 12))
        canvas = paint(canvas, hl, (255, 255, 255))
        # 위 눈꺼풀 굵게(바깥으로 갈수록), 아래 눈꺼풀 바깥 절반 가늘게, 쌍꺼풀 선 옅게
        stroke(canvas, u, INK_, th * V["lash"], taper=True)
        stroke(canvas, l[len(l) // 2:], (110, 90, 80), th * 0.55, taper=True)
        crease = u[2:-2].copy(); crease[:, 1] -= ew * 0.12
        stroke(canvas, crease, (140, 118, 108), th * 0.5, taper=True)
        d = u[-1] - u[-3]; d = d / (np.linalg.norm(d) + 1e-6)
        tip_ = u[-1] + d * ew * 0.10 + np.array([0, -ew * 0.05])
        cv2.line(canvas, tuple(u[-1].astype(int)), tuple(tip_.astype(int)), _col(INK_), max(1, int(th * 1.1)), cv2.LINE_AA)

    # ---- 코
    tip = p468[4]
    nose_c = (120, 95, 85)
    if V["nose"] == "tiny":
        pts = np.array([tip + (-fw * 0.015, -fw * 0.01), tip + (-fw * 0.012, fw * 0.015), tip + (fw * 0.008, fw * 0.018)], np.float32)
        stroke(canvas, pts, INK_, th * 0.7, smooth=False)
    elif V["nose"] == "dot":
        cv2.circle(canvas, (int(tip[0]), int(tip[1] + fw * 0.01)), max(2, int(th * 0.9)), _col(INK_), -1, cv2.LINE_AA)
    elif V["nose"] == "side":
        # 콧대 한쪽 선 (코 옆 윤곽 점들) + 코밑 곡선
        side = p468[[196, 3, 51, 45, 220]]
        stroke(canvas, side, nose_c, th * 0.55, taper=True)
        stroke(canvas, p468[NOSE_BASE_C], nose_c, th * 0.75, taper=True)
    else:
        stroke(canvas, p468[NOSE_BASE_C], nose_c, th * 0.75, taper=True)

    # ---- 입
    lips_pts = p468[LIPS]
    if base is None:
        mc = lips_pts.mean(0)
        lips_pts = mc + (lips_pts - mc) * np.array([T["mouth"] ** 0.6, T["lip"] ** 0.6], np.float32)
    lip_m = np.zeros((h, w), np.uint8)
    cv2.fillPoly(lip_m, [_i32(catmull(lips_pts, closed=True))], 255)
    lip_src = np.zeros((h, w), np.uint8)
    cv2.fillPoly(lip_src, [_i32(catmull(p468[LIPS], closed=True))], 255)
    lip_c = median_color(img, cv2.bitwise_and(lip_src, person), 50)
    lip_c = adjust(lip_c, light=1.0, sat=1.3 * V["sat"])
    lip_c = lip_c * 0.75 + np.array((130, 120, 225), np.float32) * 0.25
    if V.get("marker"):                                    # 마커 캐리커처: 피부색과 섞은 연한 분홍 (립스틱처럼 안 되게)
        lip_c = skin_c * 0.45 + np.array((150, 135, 240), np.float32) * 0.55
    inner = np.zeros((h, w), np.uint8)
    cv2.fillPoly(inner, [_i32(catmull(p468[LIPS_IN], closed=True))], 255)
    open_ratio = inner.sum() / max(lip_m.sum(), 1)
    if V["mouth"] == "lips":
        canvas = paint(canvas, lip_m, lip_c)
    elif V["mouth"] == "soft":                           # 입술색 은은하게 (남자 입술이 립스틱처럼 되지 않게)
        a = (cv2.GaussianBlur(lip_m, (0, 0), fw * 0.008).astype(np.float32) / 255 * 0.5)[..., None]
        canvas = canvas * (1 - a) + lip_c * a
    elif open_ratio > 0.12:
        a = (lip_m.astype(np.float32) / 255 * 0.5)[..., None]
        canvas = canvas * (1 - a) + lip_c * a
    if open_ratio > 0.12:
        canvas = paint(canvas, inner, (60, 40, 45))
        rows = (np.arange(h)[:, None] < p468[[13, 14], 1].mean()).repeat(w, 1).astype(np.uint8) * 255
        canvas = paint(canvas, cv2.bitwise_and(inner, rows), (245, 245, 248))
        stroke(canvas, p468[LIPS_IN[:11]], INK_, th * 0.6)
        stroke(canvas, lips_pts, adjust(lip_c, light=0.6, sat=1.2), th * 0.55, closed=True)
    elif V["mouth"] == "simple":
        line = _scale_poly(p468[[78, 82, 13, 312, 308]], 0.85, 1.0)
        stroke(canvas, line, INK_, th * 0.9, taper=True)
    else:
        stroke(canvas, p468[[78, 82, 13, 312, 308]], INK_, th * 0.8, taper=True)
        stroke(canvas, lips_pts, adjust(lip_c, light=0.6, sat=1.2), th * 0.55, closed=True)

    # ---- 안경: 사진 선을 베끼면 지저분해서, 메시 기준으로 단순한 안경을 새로 그린다 (캐리커처 작가 방식)
    if glasses:
        g = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        centers = []
        for up, lo in ((EYE_R_UP, EYE_R_LO), (EYE_L_UP, EYE_L_LO)):
            poly = np.vstack([p468[up], p468[lo][::-1]])
            centers.append((poly.mean(0), float(np.linalg.norm(p468[up][-1] - p468[up][0]))))
        iod = float(np.linalg.norm(centers[0][0] - centers[1][0]))
        lw, lh = iod * 0.44, iod * 0.36                       # 렌즈 반지름 (가로·세로)
        # 사진의 안경테가 진한지(검은 뿔테) 가는지(금속테) 보고 선 굵기 결정
        band = np.zeros((h, w), np.uint8)
        for c, _ in centers:
            cv2.ellipse(band, (int(c[0]), int(c[1] + iod * 0.06)), (int(lw), int(lh)), 0, 0, 360, 255, max(3, int(th * 3)))
        dark_frac = float((g[band > 0] < 60).mean()) if band.any() else 0.0
        fw = th * (2.4 if dark_frac > 0.25 else 1.3)
        frame_c = INK_ if dark_frac > 0.25 else (90, 80, 76)
        lens = np.zeros((h, w), np.uint8)
        for c, _ in centers:
            cv2.ellipse(lens, (int(c[0]), int(c[1] + iod * 0.06)), (int(lw), int(lh)), 0, 0, 360, 255, -1, cv2.LINE_AA)
        a = (lens.astype(np.float32) / 255 * 0.10)[..., None]      # 렌즈 살짝 밝게
        canvas = canvas * (1 - a) + 255.0 * a
        for c, _ in centers:
            cv2.ellipse(canvas, (int(c[0]), int(c[1] + iod * 0.06)), (int(lw), int(lh)), 0, 0, 360, _col(frame_c), max(1, int(round(fw))), cv2.LINE_AA)
        # 브리지(코 위) + 다리(귀 쪽으로)
        (c0, _), (c1, _) = centers
        left, right = (c0, c1) if c0[0] < c1[0] else (c1, c0)
        y_b = (left[1] + right[1]) / 2 + iod * 0.02
        cv2.line(canvas, (int(left[0] + lw), int(y_b)), (int(right[0] - lw), int(y_b)), _col(frame_c), max(1, int(round(fw * 0.8))), cv2.LINE_AA)
        for c, sgn, ear in ((left, -1, 234), (right, 1, 454)):
            x0, y0 = int(c[0] + sgn * lw), int(c[1] + iod * 0.02)
            x1, y1 = int(p468[ear, 0]), int(p468[ear, 1] - iod * 0.05)
            if (x1 - x0) * sgn > 0:
                cv2.line(canvas, (x0, y0), (x1, y1), _col(frame_c), max(1, int(round(fw * 0.8))), cv2.LINE_AA)
        # 렌즈 반사: 작은 흰 사선 하나
        for c, _ in centers:
            p0 = (int(c[0] - lw * 0.55), int(c[1] + iod * 0.06 - lh * 0.2))
            p1 = (int(c[0] - lw * 0.25), int(c[1] + iod * 0.06 - lh * 0.6))
            cv2.line(canvas, p0, p1, (255, 255, 255), max(1, int(th * 0.9)), cv2.LINE_AA)

    ROUGH = 0.0
    if V.get("grain", 0) > 0:                             # 종이 결 (인쇄된 만화 느낌)
        rng = np.random.default_rng(7)
        n1 = cv2.GaussianBlur(rng.random((h, w), dtype=np.float32), (0, 0), 1.0)
        n2 = cv2.GaussianBlur(rng.random((h, w), dtype=np.float32), (0, 0), 5.0)
        tex = 1.0 + V["grain"] * ((n1 - 0.5) * 1.6 + (n2 - 0.5) * 2.5)
        canvas = canvas * tex[..., None]
    return np.clip(canvas, 0, 255).astype(np.uint8)
