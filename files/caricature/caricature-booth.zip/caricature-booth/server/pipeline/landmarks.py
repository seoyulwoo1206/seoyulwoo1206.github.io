"""
② 특징 추출: 얼굴 메시 468개 점 → 개성 수치 계산

- 특징점 검출: MediaPipe Face Mesh (468점, ONNX로 변환, 2.4MB) — 눈·코·입뿐 아니라 이마·볼까지 촘촘히
- 그중 68개(iBUG 규칙)를 골라 눈 크기, 입 너비 같은 수치를 평균 얼굴과 비교한다.
"""
import cv2
import numpy as np
import onnxruntime as ort

from .config import MODELS

# ---- 468점 중 '대표 68점' (iBUG 300-W 번호 순서) --------------------------------------
MP68 = np.array([
    127, 234, 93, 132, 58, 172, 136, 150, 176, 152, 400, 379, 365, 397, 288, 361, 356,  # 턱선 0-16
    70, 63, 105, 66, 107,            # 오른 눈썹 17-21 (사진 기준 왼쪽)
    336, 296, 334, 293, 300,         # 왼 눈썹 22-26
    168, 197, 5, 4,                  # 콧대 27-30
    75, 97, 2, 326, 305,             # 코 밑 31-35
    33, 160, 158, 133, 153, 144,     # 오른 눈 36-41
    362, 385, 387, 263, 373, 380,    # 왼 눈 42-47
    61, 39, 37, 0, 267, 269, 291, 405, 314, 17, 84, 181,   # 입 바깥 48-59
    78, 82, 13, 312, 308, 317, 14, 87,                      # 입 안쪽 60-67
])

# 68점 번호 묶음
JAW = list(range(0, 17))
BROW_R, BROW_L = list(range(17, 22)), list(range(22, 27))
NOSE_BRIDGE, NOSE_BASE = list(range(27, 31)), list(range(31, 36))
EYE_R, EYE_L = list(range(36, 42)), list(range(42, 48))
MOUTH_OUT, MOUTH_IN = list(range(48, 60)), list(range(60, 68))
PARTS = [(JAW, False), (BROW_R, False), (BROW_L, False), (NOSE_BRIDGE, False), (NOSE_BASE, False),
         (EYE_R, True), (EYE_L, True), (MOUTH_OUT, True), (MOUTH_IN, True)]

# 68점 각각이 속한 부위 → 468점은 '가장 가까운 68점'의 부위를 물려받는다
GROUP_OF_68 = {}
for _g, _idx in [("jaw", JAW), ("brow", BROW_R + BROW_L), ("nose", NOSE_BRIDGE + NOSE_BASE),
                 ("eye_r", EYE_R), ("eye_l", EYE_L), ("mouth", MOUTH_OUT + MOUTH_IN)]:
    for _i in _idx:
        GROUP_OF_68[_i] = _g

MESH_INPUT = 192
ROI_SCALE = 1.5   # 얼굴 박스의 1.5배 정사각형을 모델에 넣는다 (MediaPipe 규칙)


def to68(p468):
    return p468[MP68]


class MeshDetector:
    def __init__(self):
        self.sess = ort.InferenceSession(str(MODELS / "face_mesh_468.onnx"), providers=["CPUExecutionProvider"])
        self.inp = self.sess.get_inputs()[0].name

    def fit(self, img, box):
        cx, cy, w, h = box
        side = max(w, h) * ROI_SCALE
        x0, y0 = int(round(cx - side / 2)), int(round(cy - side / 2))
        x1, y1 = int(round(cx + side / 2)), int(round(cy + side / 2))
        H, W = img.shape[:2]
        # 이미지 밖으로 나가면 배경색으로 채워서 정사각형 유지
        pad = max(0, -x0, -y0, x1 - W, y1 - H)
        src = cv2.copyMakeBorder(img, pad, pad, pad, pad, cv2.BORDER_REPLICATE) if pad else img
        roi = src[y0 + pad:y1 + pad, x0 + pad:x1 + pad]
        inp = cv2.cvtColor(cv2.resize(roi, (MESH_INPUT, MESH_INPUT), interpolation=cv2.INTER_AREA), cv2.COLOR_BGR2RGB)
        inp = (inp.astype(np.float32) / 255.0)[None]
        raw, flag = self.sess.run(None, {self.inp: inp})
        conf = 1.0 / (1.0 + np.exp(-float(flag.flatten()[-1])))
        if conf < 0.5:
            raise RuntimeError("얼굴이 화면에 다 안 들어왔거나 많이 돌아갔어요. 얼굴 전체가 보이게 정면으로 다시 찍어주세요.")
        lm = raw.reshape(468, 3)[:, :2] / MESH_INPUT
        pts = lm * np.array([roi.shape[1], roi.shape[0]], np.float32) + np.array([x0, y0], np.float32)
        return pts.astype(np.float32)


def group_labels(p468):
    """468점 각각의 부위 이름 (가장 가까운 대표 68점 기준)"""
    p68 = to68(p468)
    d = np.linalg.norm(p468[:, None, :] - p68[None, :, :], axis=2)
    nearest = d.argmin(1)
    iod = np.linalg.norm(p68[EYE_L].mean(0) - p68[EYE_R].mean(0))
    labels = np.array([GROUP_OF_68[int(i)] for i in nearest], dtype=object)
    # 어느 부위에서도 먼 점(볼·이마)은 '기타'
    labels[d.min(1) > 0.45 * iod] = "other"
    return labels


# ---- 수치 계산 (68점 기준) ------------------------------------------------------------
def _poly_area(q):
    x, y = q[:, 0], q[:, 1]
    return 0.5 * abs(np.dot(x, np.roll(y, 1)) - np.dot(y, np.roll(x, 1)))


def measure(p):
    """두 눈 사이 거리(IOD)로 나눠서 얼굴 크기와 상관없는 비율로 만든다. p는 68점."""
    er, el = p[EYE_R].mean(0), p[EYE_L].mean(0)
    iod = np.linalg.norm(el - er)
    d = lambda a, b: np.linalg.norm(p[a] - p[b]) / iod
    mouth_mid_y = (p[51, 1] + p[57, 1]) / 2
    return {
        "eye": (_poly_area(p[EYE_R]) + _poly_area(p[EYE_L])) / 2 / iod ** 2,
        "mouth": d(48, 54),
        "nose_len": d(27, 33),
        "nose_wid": d(31, 35),
        "jaw": d(4, 12),
        "face_len": d(27, 8),
        "brow": (np.mean(p[EYE_R + EYE_L, 1]) - np.mean(p[BROW_R + BROW_L, 1])) / iod,
        "smile": (mouth_mid_y - (p[48, 1] + p[54, 1]) / 2) / iod,
    }


FEATURE_NAMES = {
    "eye": "눈 크기", "mouth": "입 너비", "nose_len": "코 길이", "nose_wid": "코 너비",
    "jaw": "턱 너비", "face_len": "얼굴 길이", "brow": "눈썹 높이", "smile": "입꼬리",
}
# 수치 → 과장할 부위
FEATURE_GROUPS = {
    "eye": ("eye_r", "eye_l"), "brow": ("brow",), "nose_len": ("nose",), "nose_wid": ("nose",),
    "mouth": ("mouth",), "smile": ("mouth",), "jaw": ("jaw",), "face_len": ("jaw",),
}


def compare(p68, ref68):
    """내 얼굴 수치 vs 기준(평균) 얼굴 수치 → 차이(%)"""
    a, b = measure(p68), measure(ref68)
    out = []
    for k, name in FEATURE_NAMES.items():
        if k == "smile":  # 입꼬리는 0 근처라서 %가 아니라 차이 자체를 점수로
            diff = (a[k] - b[k]) * 280
        else:
            diff = (a[k] / b[k] - 1) * 100
        out.append({"key": k, "name": name, "diff": float(np.clip(diff, -60, 60))})
    return out


def draw_landmarks(img, p468, color=(255, 196, 77), dot=(60, 120, 255)):
    v = img.copy()
    for q in p468:
        cv2.circle(v, (int(q[0]), int(q[1])), 1, color, -1, cv2.LINE_AA)
    p68 = to68(p468)
    for idx, closed in PARTS:
        cv2.polylines(v, [p68[idx].astype(np.int32)], closed, dot, 1, cv2.LINE_AA)
    return v
