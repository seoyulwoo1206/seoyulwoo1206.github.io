"""
⑥ 그림체 'AI 캐리커처' — 그림은 원격 GPU 서버(Colab)가 그린다.

부스 노트북에는 GPU가 없어서, 과장까지 끝난 사진을 Colab의 그림 생성 모델에 보내고 결과 그림을 받아온다.
책 8장 '모델 서빙'의 원격 서빙 구조: 무거운 모델은 서버에, 가벼운 전처리는 현장 기기에.
서버가 꺼져 있거나 늦으면 RemoteError → 파이프라인이 기존 그림체로 자동 전환한다.
"""
import json
import urllib.error
import urllib.request

import cv2
import numpy as np

from .config import DATA

URL_FILE = DATA / "remote_url.txt"
TIMEOUT = 60          # 초. 생성 10초 + 대기열 여유 (실패하면 한 번 더 시도)


class RemoteError(RuntimeError):
    pass


def get_url():
    try:
        return URL_FILE.read_text(encoding="utf-8").strip().rstrip("/")
    except OSError:
        return ""


def set_url(url):
    url = (url or "").strip().rstrip("/")
    if url and not url.startswith(("http://", "https://")):
        url = "https://" + url
    URL_FILE.parent.mkdir(parents=True, exist_ok=True)
    URL_FILE.write_text(url, encoding="utf-8")
    return url


def health(url=None, timeout=8):
    """서버가 살아 있는지. 반환: (ok, 설명)"""
    url = url if url is not None else get_url()
    if not url:
        return False, "주소가 설정되지 않았어요"
    try:
        with urllib.request.urlopen(url + "/health", timeout=timeout) as r:
            info = json.loads(r.read().decode("utf-8"))
        return bool(info.get("ok")), info.get("gpu", "연결됨")
    except Exception as e:
        return False, f"연결 실패: {str(e)[:80]}"


def encode(img_bgr, mask=None, size=512):
    """서버로 보낼 사진. 사람 영역(mask, 0~1)이 있으면 투명도로 같이 실어 보낸다 → 서버가 배경을 깨끗한 종이로 정리"""
    small = cv2.resize(img_bgr, (size, size), interpolation=cv2.INTER_AREA)
    if mask is None:
        return cv2.imencode(".jpg", small, [cv2.IMWRITE_JPEG_QUALITY, 93])[1].tobytes(), "image/jpeg"
    a = cv2.resize((np.clip(mask, 0, 1) * 255).astype(np.uint8), (size, size), interpolation=cv2.INTER_AREA)
    return cv2.imencode(".png", np.dstack([small, a]))[1].tobytes(), "image/png"


def caricature(img_bgr, strength=1.5, size=512, beauty=False, glasses=False, mask=None, tries=2):
    """사진(BGR) → 원격 서버가 그린 캐리커처(BGR, 입력과 같은 크기). 한 번 실패하면 한 번 더 시도한다"""
    url = get_url()
    if not url:
        raise RemoteError("AI 서버 주소가 없어요")
    h, w = img_bgr.shape[:2]
    body, ctype = encode(img_bgr, mask, size)
    last = ""
    for _ in range(tries):
        req = urllib.request.Request(f"{url}/caricature?strength={strength:.2f}&beauty={int(bool(beauty))}&glasses={int(bool(glasses))}", data=body,
                                     headers={"Content-Type": ctype}, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=TIMEOUT) as r:
                data = r.read()
        except (urllib.error.URLError, TimeoutError, OSError) as e:
            last = f"AI 서버 응답 없음: {str(e)[:80]}"
            continue
        out = cv2.imdecode(np.frombuffer(data, np.uint8), cv2.IMREAD_COLOR)
        if out is None:
            last = "AI 서버가 그림을 돌려주지 않았어요"
            continue
        return cv2.resize(out, (w, h), interpolation=cv2.INTER_LANCZOS4)
    raise RemoteError(last)


# ---- 폰으로 찍기: 폰 → (인터넷) → Colab 서버 → 부스가 받아온다. 폰과 부스 PC가 같은 와이파이가 아니어도 된다
def phone_state():
    """반환: (지금까지 받은 사진 번호, 폰에서 열 주소). 서버가 없으면 RemoteError"""
    url = get_url()
    if not url:
        raise RemoteError("AI 서버 주소가 없어요")
    try:
        with urllib.request.urlopen(url + "/phone/state", timeout=8) as r:
            return int(json.loads(r.read().decode("utf-8")).get("id", 0)), url + "/phone"
    except Exception as e:
        raise RemoteError(f"연결 실패: {str(e)[:80]}")


def phone_latest(after):
    """after번보다 새 사진이 있으면 (번호, JPEG 바이트), 없으면 None"""
    url = get_url()
    if not url:
        return None
    try:
        with urllib.request.urlopen(f"{url}/phone/latest?after={int(after)}", timeout=10) as r:
            if r.status != 200:
                return None
            return int(r.headers.get("X-Photo-Id", "0")), r.read()
    except Exception:
        return None
