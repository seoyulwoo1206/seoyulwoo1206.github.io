// 캐리커처 부스 화면
// 주소 뒤에 ?delay=2500 처럼 붙이면 단계별 설명 시간(ms)을 바꿀 수 있어요.
const STEP_DELAY = Number(new URLSearchParams(location.search).get("delay") || 2200);

const $ = (s) => document.querySelector(s);
const S = { config: null, style: null, photo: null, stream: null, jobId: null, job: null, shown: 0, lastShow: 0, timer: null };


// ---------------------------------------------------------------- 화면 전환
function go(id) {
  document.querySelectorAll(".screen").forEach((s) => s.classList.toggle("active", s.id === id));
  if (id === "capture") { startCamera(); startPhone(); } else { stopCamera(); stopPhone(); }
}
document.querySelectorAll("[data-go]").forEach((b) => b.addEventListener("click", () => go(b.dataset.go)));

// ---------------------------------------------------------------- 설정 불러오기
async function init() {
  S.config = await (await fetch("/api/config")).json();
  const list = $("#styleList");
  const marks = { ai: "AI", marker: "✎", romance: "♡", comedy: "ㅋ", daily: "日", watercolor: "〰", paint: "Aa", sketch: "✎" };
  S.config.styles.forEach((st) => {
    const b = document.createElement("button");
    b.className = "style-card";
    b.innerHTML = `<div class="sw sw-${st.key}">${marks[st.key] || ""}</div><h3>${st.name}</h3><p>${st.desc}</p>`;
    b.onclick = () => {
      S.style = st.key;
      list.querySelectorAll(".style-card").forEach((c) => c.classList.toggle("on", c === b));
      $("#toCapture").disabled = false;
    };
    list.appendChild(b);
  });
  const r = $("#strength");
  r.min = S.config.strength.min; r.max = S.config.strength.max; r.value = S.config.strength.default;
  const word = (v) => (v < 1.25 ? "살짝" : v < 1.75 ? "보통" : v < 2.15 ? "세게" : "최대");
  const showStrength = () => ($("#strengthOut").textContent = `×${Number(r.value).toFixed(1)} ${word(Number(r.value))}`);
  r.oninput = showStrength; showStrength();

  const tl = $("#timeline");
  S.config.steps.forEach((st, i) => {
    const li = document.createElement("li");
    li.innerHTML = `<span class="n">${i + 1}</span><span>${st.title}</span><span class="ms"></span>`;
    tl.appendChild(li);
  });
}
$("#toCapture").onclick = () => go("capture");

// ---------------------------------------------------------------- 카메라
function camPref(key, val) {
  try { if (val === undefined) return localStorage.getItem(key); localStorage.setItem(key, val); } catch (e) { return null; }
}
async function listCameras() {
  const sel = $("#camSelect");
  try {
    const devs = (await navigator.mediaDevices.enumerateDevices()).filter((d) => d.kind === "videoinput");
    sel.innerHTML = "";
    devs.forEach((d, i) => {
      const o = document.createElement("option");
      o.value = d.deviceId; o.textContent = d.label || `카메라 ${i + 1}`;
      sel.appendChild(o);
    });
    const saved = camPref("camId");
    if (saved && [...sel.options].some((o) => o.value === saved)) sel.value = saved;
    sel.parentElement.hidden = devs.length < 2;
  } catch (e) { sel.parentElement.hidden = true; }
}
function applyMirror() {
  const on = $("#mirror").checked;
  $("#video").style.transform = on ? "scaleX(-1)" : "none";
  camPref("mirror", on ? "1" : "0");
}
async function startCamera() {
  resetShot();
  stopCamera();
  try {
    const id = $("#camSelect").value || camPref("camId");
    const video = { width: { ideal: 1920 }, height: { ideal: 1080 } };
    if (id) video.deviceId = { exact: id }; else video.facingMode = "user";
    S.stream = await navigator.mediaDevices.getUserMedia({ video, audio: false });
    $("#video").srcObject = S.stream;
    $("#camMsg").hidden = true;
    $("#shootBtn").disabled = false;
    await listCameras();           // 권한을 받은 뒤에야 카메라 이름이 보인다
    const cur = S.stream.getVideoTracks()[0].getSettings().deviceId;
    if (cur) { $("#camSelect").value = cur; camPref("camId", cur); }
  } catch (e) {
    $("#camMsg").hidden = false;
    $("#shootBtn").disabled = true;
  }
}
$("#camSelect").onchange = () => { camPref("camId", $("#camSelect").value); startCamera(); };
$("#mirror").onchange = applyMirror;
$("#mirror").checked = camPref("mirror") !== "0";
applyMirror();
function stopCamera() {
  if (S.stream) S.stream.getTracks().forEach((t) => t.stop());
  S.stream = null;
}
function resetShot() {
  S.photo = null;
  $("#shot").hidden = true; $("#video").hidden = false;
  $("#shootBtn").hidden = false; $("#retakeBtn").hidden = true; $("#useBtn").hidden = true;
}
function showShot(blob) {
  S.photo = blob;
  $("#shot").src = URL.createObjectURL(blob);
  $("#shot").hidden = false; $("#video").hidden = true;
  $("#shootBtn").hidden = true; $("#retakeBtn").hidden = false; $("#useBtn").hidden = false;
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

$("#shootBtn").onclick = async () => {
  $("#shootBtn").disabled = true;
  for (const n of [3, 2, 1]) { $("#count").textContent = n; await sleep(800); }
  $("#count").textContent = "";
  const v = $("#video");
  const c = document.createElement("canvas");
  c.width = v.videoWidth; c.height = v.videoHeight;
  const ctx = c.getContext("2d");
  if ($("#mirror").checked) { ctx.translate(c.width, 0); ctx.scale(-1, 1); } // 거울 모드면 보이는 그대로 저장
  ctx.drawImage(v, 0, 0);
  $("#flash").classList.remove("go"); void $("#flash").offsetWidth; $("#flash").classList.add("go");
  c.toBlob((b) => showShot(b), "image/jpeg", 0.92);
  $("#shootBtn").disabled = false;
};
$("#retakeBtn").onclick = resetShot;
$("#fileInput").onchange = (e) => { const f = e.target.files[0]; if (f) showShot(f); e.target.value = ""; };
$("#useBtn").onclick = submit;

// ---------------------------------------------------------------- 서버로 보내기
async function submit() {
  const fd = new FormData();
  fd.append("photo", S.photo, "photo.jpg");
  fd.append("style", S.style || "paint");
  fd.append("strength", $("#strength").value);
  fd.append("nickname", $("#nickname").value);
  fd.append("consent", $("#consent").checked);
  fd.append("glasses", $("#glasses").checked);
  fd.append("beauty", $("#beauty").checked);
  resetProcess();
  go("process");
  try {
    const r = await fetch("/api/jobs", { method: "POST", body: fd });
    if (!r.ok) throw new Error((await r.json()).detail || "전송 실패");
    S.jobId = (await r.json()).id;
    poll();
  } catch (e) { showError(e.message); }
}

function resetProcess() {
  S.job = null; S.shown = 0; S.lastShow = 0; clearTimeout(S.timer);
  $("#stageImg").removeAttribute("src"); $("#spinner").hidden = false;
  $("#stageNum").textContent = ""; $("#stageTitle").textContent = "사진을 보내는 중…"; $("#stageDesc").textContent = "";
  $("#metrics").hidden = true; $("#toResult").hidden = true; $("#totalMsg").textContent = ""; $("#queueMsg").textContent = "";
  document.querySelectorAll("#timeline li").forEach((li) => { li.className = ""; li.querySelector(".ms").textContent = ""; });
}

async function poll() {
  try {
    S.job = await (await fetch(`/api/jobs/${S.jobId}`)).json();
  } catch { /* 잠깐 끊겨도 다시 시도 */ }
  const job = S.job;
  if (job) {
    if (job.status === "error") return showError(job.error);
    $("#queueMsg").textContent = job.status === "queued" && job.ahead ? `· 앞에 ${job.ahead}명 대기 중` : "";
    if (job.status === "running" && S.shown === 0) $("#stageTitle").textContent = "코드가 돌아가는 중…";
    revealNext();
  }
  const finished = job && job.status === "done" && S.shown >= S.config.steps.length;
  if (!finished) S.timer = setTimeout(poll, 350);
}

// 서버는 2~3초 만에 끝나지만, 설명할 시간을 주려고 한 단계씩 천천히 보여준다
function revealNext() {
  const steps = S.job.steps || [];
  const now = Date.now();
  if (S.shown < steps.length && now - S.lastShow >= (S.shown === 0 ? 300 : STEP_DELAY)) {
    showStep(S.shown, steps[S.shown]);
    S.shown++; S.lastShow = now;
  }
  if (S.job.status === "done" && S.shown >= S.config.steps.length && $("#toResult").hidden) {
    setTimeout(() => {
      $("#toResult").hidden = false;
      $("#totalMsg").innerHTML = `실제 처리 시간 <b>${(S.job.total_ms / 1000).toFixed(1)}초</b>` + (S.job.fallback ? " · AI 서버 연결이 안 돼서 물감 일러스트로 그렸어요" : "");
    }, STEP_DELAY * 0.6);
  }
}

function showStep(i, st) {
  const meta = S.config.steps[i];
  const img = $("#stageImg");
  img.classList.remove("swap"); void img.offsetWidth; img.classList.add("swap");
  img.src = st.file;
  $("#spinner").hidden = true;
  $("#stageNum").textContent = `${i + 1}단계 · ${st.ms}ms`;
  $("#stageTitle").textContent = meta.title;
  $("#stageDesc").textContent = meta.desc;
  if (st.key === "exaggerate" && S.job && S.job.strong && S.job.metrics) {
    const names = S.job.strong.map((k) => (S.job.metrics.find((m) => m.key === k) || {}).name).filter(Boolean);
    if (names.length) $("#stageDesc").textContent += ` 이번엔 가장 튀는 「${names.join(", ")}」을 세게 과장했어요.`;
  }
  const lis = document.querySelectorAll("#timeline li");
  lis.forEach((li, j) => { li.classList.toggle("now", j === i); });
  lis[i].classList.add("done");
  lis[i].querySelector(".ms").textContent = `${st.ms}ms`;
  const showMetrics = (st.key === "compare" || st.key === "exaggerate");
  if (showMetrics) waitMetrics(); else $("#metrics").hidden = true;
}

function waitMetrics() {
  if (S.job && S.job.metrics) renderMetrics(S.job.metrics, S.job.reference);
  else setTimeout(waitMetrics, 200);
}

function topFeatures(metrics, n = 3) {
  return [...metrics].sort((a, b) => Math.abs(b.diff) - Math.abs(a.diff)).slice(0, n);
}
function renderMetrics(metrics, ref) {
  const top = new Set(topFeatures(metrics).map((m) => m.key));
  const refName = ref === "booth" ? "오늘 부스 방문자 평균 얼굴" : "학습 데이터 평균 얼굴";
  $("#metrics").innerHTML = `<h4>${refName}과 비교한 내 얼굴 (가운데 선 = 평균)</h4>` +
    metrics.map((m) => {
      const w = Math.min(50, Math.abs(m.diff) * 50 / 60);
      const left = m.diff >= 0 ? 50 : 50 - w;
      const val = m.key === "smile" ? (m.diff >= 0 ? "↑" : "↓") : `${m.diff >= 0 ? "+" : ""}${Math.round(m.diff)}%`;
      return `<div class="mrow ${top.has(m.key) ? "top" : ""}"><span>${m.name}</span><div class="mbar"><i style="left:${left}%;width:${w}%"></i></div><span>${val}</span></div>`;
    }).join("");
  $("#metrics").hidden = false;
}

function showError(msg) {
  clearTimeout(S.timer);
  $("#spinner").hidden = true;
  $("#stageNum").textContent = "앗!";
  $("#stageTitle").textContent = "다시 찍어볼까요?";
  $("#stageDesc").textContent = msg;
  $("#toResult").hidden = false;
  $("#toResult").textContent = "다시 찍기";
  $("#toResult").onclick = () => { $("#toResult").textContent = "완성작 보기"; $("#toResult").onclick = toResult; go("capture"); };
}

// ---------------------------------------------------------------- 결과 + 인쇄
function toResult() {
  const last = S.job.steps[S.job.steps.length - 1];
  $("#resultImg").src = last.file;
  const nick = $("#nickname").value.trim();
  $("#pcName").textContent = nick ? `${nick}의 캐리커처` : "나만의 캐리커처";
  const top = topFeatures(S.job.metrics, 2).map((m) => m.key === "smile" ? `입꼬리 ${m.diff >= 0 ? "↑" : "↓"}` : `${m.name} ${m.diff >= 0 ? "+" : ""}${Math.round(m.diff)}%`);
  $("#pcFeat").textContent = `나의 개성 · ${top.join(" · ")}`;
  const d = new Date();
  $("#pcDate").textContent = `${d.getFullYear()}.${d.getMonth() + 1}.${d.getDate()} · 처리 시간 ${(S.job.total_ms / 1000).toFixed(1)}초`;
  go("result");
}
$("#toResult").onclick = toResult;
$("#printBtn").onclick = () => window.print();
$("#againBtn").onclick = () => {
  $("#nickname").value = ""; $("#consent").checked = false; $("#glasses").checked = false; $("#beauty").checked = true; S.style = null;
  document.querySelectorAll(".style-card").forEach((c) => c.classList.remove("on"));
  $("#toCapture").disabled = true;
  go("home");
};

// ---------------------------------------------------------------- 퀴즈
async function openQuiz() {
  $("#quiz").hidden = false;
  await nextQuiz();
}
async function nextQuiz() {
  const q = await (await fetch(`/api/quiz?exclude=${S.jobId || ""}`)).json();
  const box = $("#choices");
  box.innerHTML = ""; $("#quizMsg").textContent = "";
  if (!q.ready) {
    $("#quizImg").hidden = true;
    $("#quizMsg").textContent = "아직 퀴즈에 참여한 친구가 부족해요. 조금 뒤에 다시 해봐요!";
    return;
  }
  $("#quizImg").hidden = false; $("#quizImg").src = q.img;
  q.choices.forEach((name) => {
    const b = document.createElement("button");
    b.textContent = name;
    b.onclick = () => {
      box.querySelectorAll("button").forEach((x) => {
        x.disabled = true;
        if (x.textContent === q.answer) x.classList.add("right");
      });
      if (name !== q.answer) b.classList.add("wrong");
      $("#quizMsg").textContent = name === q.answer ? "정답! 특징을 잘 잡았죠?" : `정답은 ${q.answer}!`;
    };
    box.appendChild(b);
  });
}
["#openQuiz", "#openQuiz2", "#openQuizHome"].forEach((s) => ($(s).onclick = openQuiz));
$("#nextQuiz").onclick = nextQuiz;
$("#closeQuiz").onclick = () => ($("#quiz").hidden = true);

init();


// ---- AI 서버(Colab) 연결: 운영자가 Colab에 뜬 주소를 붙여넣는다
async function refreshRemote() {
  try {
    const r = await (await fetch("/api/remote")).json();
    const dot = $("#remoteDot");
    dot.style.color = r.ok ? "#2ecc71" : "#e74c3c";
    dot.title = r.ok ? `연결됨 (${r.info})` : r.info;
    return r;
  } catch (e) { return { ok: false, url: "", info: "" }; }
}
$("#remoteBtn").onclick = async () => {
  const cur = await refreshRemote();
  const url = window.prompt(`AI 서버 주소 (Colab 노트북에 뜬 https://….trycloudflare.com)\n현재: ${cur.url || "없음"} — ${cur.ok ? "연결됨" : cur.info}`, cur.url || "");
  if (url === null) return;
  const fd = new FormData(); fd.append("url", url);
  const r = await (await fetch("/api/remote", { method: "POST", body: fd })).json();
  await refreshRemote();
  window.alert(r.ok ? `연결 성공! (${r.info})` : `연결 실패: ${r.info}\nAI 캐리커처를 고르면 물감 일러스트로 대신 그려요.`);
};
refreshRemote();


// ---- 폰으로 찍기: 폰이 Colab 서버로 보낸 사진을 받아온다 (촬영 화면에 있는 동안 계속 확인)
const P = { on: false, after: 0, timer: null };
async function startPhone() {
  stopPhone();
  let r = { ok: false };
  try { r = await (await fetch("/api/phone/start")).json(); } catch (e) { /* 서버 없음 */ }
  $("#phoneBtn").hidden = !r.ok;                       // AI 서버가 연결돼 있을 때만 보인다
  if (!r.ok || !$("#capture").classList.contains("active")) return;
  P.on = true; P.after = r.id;
  pollPhone();
}
function stopPhone() { P.on = false; clearTimeout(P.timer); $("#phone").hidden = true; }
async function pollPhone() {
  if (!P.on) return;
  try {
    const r = await fetch(`/api/phone/poll?after=${P.after}`);
    if (r.status === 200 && P.on) {
      P.after = Number(r.headers.get("X-Photo-Id")) || P.after + 1;
      showShot(await r.blob());
      $("#phone").hidden = true;
      $("#phoneDot").style.color = "#2ecc71";
    }
  } catch (e) { /* 잠깐 끊겨도 다시 시도 */ }
  if (P.on) P.timer = setTimeout(pollPhone, 1500);
}
$("#phoneBtn").onclick = () => { $("#phoneQr").src = "/api/phone/qr?t=" + Date.now(); $("#phone").hidden = false; };
$("#closePhone").onclick = () => ($("#phone").hidden = true);
